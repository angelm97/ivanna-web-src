<?
/*
************************************************************
**********#	Name	: Shambhu Prasad Patnaik         #******
**********#	Company	: Aynsoft	Pvt. Ltd.       #***********
**********#	Copyright (c) www.aynsoft.com 2018	#***********
************************************************************
*/
ini_set('max_execution_time','0');
include_once("../include_files.php");
include_once("../general_functions/zip_recruiter_xml_import.php");
zip_recruiter_job_import();
?>