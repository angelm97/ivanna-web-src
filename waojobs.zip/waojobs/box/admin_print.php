<?
/*
***********************************************************
***********************************************************
**********# Name          : Kamal Kumar Sahoo   #**********
**********# Company       : Aynsoft             #**********
**********# Date Created  : 11/02/04            #**********
**********# Date Modified : 11/02/04            #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
***********************************************************
***********************************************************
*/
$heading = array();
$contents = array();
$heading[] = array('text'  => BOX_HEADING_PRINT,
					'link'  => FILENAME_ADMIN1_JOBSEEKER_PRINT.'?selected_box=admin_print',
                   'default_row'=>(($_SESSION['selected_box'] == 'admin_print') ?'1':''),
                   'text_image'=>'<i class="fas fa-print admin-left-icon"></i>',
                  );

if ($_SESSION['selected_box'] == 'admin_print')
{
 $blank_space='&nbsp;&nbsp;&nbsp;<img src="../img/red_aero.gif">&nbsp;';
 $content=tep_admin_files_boxes(FILENAME_ADMIN1_JOBSEEKER_PRINT, BOX_PRINT_JOBSEEKER);
 if(tep_not_null($content))
 {
	 $contents[] = array('text'=>$blank_space.$content);
 }
 $content=tep_admin_files_boxes(FILENAME_ADMIN1_RECRUITER_PRINT, BOX_PRINT_RECRUITER);
 if(tep_not_null($content))
 {
	 $contents[] = array('text'=>$blank_space.$content);
 }
}
$box = new left_box;
$LEFT_HTML.=$box->menuBox($heading, $contents);
?>