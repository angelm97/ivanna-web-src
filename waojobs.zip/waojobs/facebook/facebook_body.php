<?
 include_once('header.php');
 include_once('header_middle.php');
 include_once('footer.php');
$template->assign_vars(array('FACEBOOK_HEADER_HTML' => FACEBOOK_HEADER_HTML,
 'FACEBOOK_HEADER_MIDDLE_HTML' => FACEBOOK_HEADER_MIDDLE_HTML,
 'INDEX_HEADER'       => INDEX_HEADER,
 'FACEBOOK_FOOTER_HTML' => FACEBOOK_FOOTER_HTML,
 'FACEBOOK_APP_ID' =>'292004620855968',//'523969917671142',
));
?>