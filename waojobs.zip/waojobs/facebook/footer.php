<?
define('FACEBOOK_FOOTER_HTML','</td></tr></table>'.tep_get_google_analytics_code().'
 </body>
</html>
');
?>