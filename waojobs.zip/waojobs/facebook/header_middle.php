<?
define('FACEBOOK_HEADER_MIDDLE_HTML','<tr><td>');
?>