<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Newsletter');
define('TABLE_HEADING_TITLE', 'Title');
define('TABLE_HEADING_INSERTED', 'Date');
define('TABLE_HEADING_VIEW', 'View');
define('INFO_TEXT_ATTACHMENT_DOWNLOAD','Attachment Download');
define('INFO_TEXT_NEWSLERRERS','Newsletters');
define('INFO_TEXT_NO_NEWSLETTER_AVAILABLE','No newsletter available');
?>