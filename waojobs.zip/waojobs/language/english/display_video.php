<?php
define('PROFILE_NOT_EXIST_MESSAGE1','Error : profile not exist.');
define('VIDEO_NOT_EXIST_MESSAGE','Error : Video not exist.');
?>