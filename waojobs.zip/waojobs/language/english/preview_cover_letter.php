<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', 'Cover letter');
//////////////////////////
define('IMAGE_CANCEL','Cancel');
define('INFO_TEXT_CLOSE','Close');
?>