<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Subscription Plan - Rate Card');
define('TABLE_HEADING_PLAN_TYPE_NAME','Membership');
define('TABLE_HEADING_PLAN_TYPE_TIME_PERIOD','Time period');
define('TABLE_HEADING_PLAN_TYPE_FEE','Fee ');
define('TABLE_HEADING_PLAN_TYPE_NO_OF_JOBS','Jobs');
define('TABLE_HEADING_PLAN_TYPE_NO_OF_CVS','CV\'s');
define('TABLE_HEADING_PLAN_TYPE_NO_OF_SMS','SMS');
define('TABLE_HEADING_PLAN_TYPE_BUY','Buy');
?>