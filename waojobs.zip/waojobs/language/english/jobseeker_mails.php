<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik#**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/
define('HEADING_TITLE', 'Response From Employers');

define('INFO_TEXT_SUBJECT', 'Subject:');
define('INFO_MAIL_ATTACHMENT', 'Attachment :');
define('INFO_TEXT_DESCRIPTION', 'Description:');
define('INFO_TEXT_MESSAGE', 'Message:');


define('TABLE_HEADING_MAIL_SENDER', 'Sender');
define('TABLE_HEADING_APPLICATION_ID', 'Application ID');
define('TABLE_HEADING_MAIL_SUBJECT', 'Subject');
define('TABLE_HEADING_MAIL_INSERTED', 'Date');

define('ERROR_MAIL_NOT_EXIST','Sorry Mail  does not exist. If problem persists please contact admin of the site.');
define('MESSAGE_SUCCESS_MARKED','Your mail successfully marked');
define('MESSAGE_SUCCESS_DELETED','Your mail successfully delete');
define('MESSAGE_SUCCESS_RESTORE','Your mail successfully  restore in inbox');
define('MESSAGE_SUCCESS_UNMARKED','Your mail successfully clear mark');
define('REPLY_SUCCESS_SENT','Success: Replay successfully sent');
define('ENTRY_MESSAGE_ERROR',' Please enter message');

define("INFO_TEXT_REPLY","Reply");


define('IMAGE_BACK', 'Back');
define('IMAGE_ATTACHMENT','Attachment');
define('INFO_TEXT_VIEW_IN','View in ');
define('INFO_TEXT_VIEW_TRASH',' Trash');
define('INFO_TEXT_VIEW_INBOX','Inbox');
define('INFO_TEXT_VIEW_SEND','Send');
define('INFO_TEXT_VIEW_IN','View in');
define('INFO_TEXT_ALL','All');
define('INFO_TEXT_SHOW_ALL','Show All');
define('INFO_TEXT_UNREAD','Unread');
define('INFO_TEXT_INBOX','Inbox');
define('INFO_TEXT_TRASH','Trash');
define('INFO_TEXT_MARKED','Marked');
define('INFO_TEXT_MAIL','Mail');
define('INFO_TEXT_MAILS','Mails');
define('INFO_TEXT_HAS_FOUND','has found');
define('INFO_TEXT_CHECK_ALL','Check All');
define('INFO_TEXT_UNCHECK_ALL','Uncheck All');
define('INFO_TEXT_WITH_SELECTED','With Selected');
define('INFO_TEXT_CLEAR_MARK','Clear Mark');
define('INFO_TEXT_DELETE','Delete');
define('INFO_TEXT_RESTORE','Restore');
define('INFO_TEXT_HAS_NOT_FOUND','has not found any mail');
?>