<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/
define('HEADING_TITLE','Job Seeker Dashboard');

define('INFO_TEXT_BRIEFPROFILE','Brief Profile');
define('INFO_TEXT_EMAIL_ADDRESS','E-Mail Address :');
define('INFO_TEXT_ADDRESS','Current Location :');
define('INFO_TEXT_PHONE','Phone No. :');
define('INFO_TEXT_MOBILE','Mobile:');
define('INFO_TEXT_RESUME_VIEWED','No. of times Resume Viewed:');
define('INFO_TEXT_ADD_PHOTO','Add Photo');
define('INFO_TEXT_EDIT_PHOTO','Edit Photo');

define('INFO_TEXT_RESUME_MANAGER','Resume Manager');
define('INFO_TEXT_ADD_RESUMES','Add Resumes');
define('INFO_TEXT_LIST_OF_RESUMES','My Resumes');

define('INFO_TEXT_JOBS','Jobs');
define('INFO_TEXT_LIST_OF_SAVED_JOBS','My saved jobs');
define('INFO_TEXT_LIST_OF_APPLICATIONS','My applications');

define('INFO_TEXT_MY_ACCOUNT','My Account');
define('INFO_TEXT_EDIT_PERSONAL_DETAILS','Edit personal details');

define('INFO_TEXT_HEADER_JOB_SEARCH','My Job Search');
define('INFO_TEXT_JOB_SEARCH','Search Jobs');
define('INFO_TEXT_SERCH_BY_LOCATION','Search jobs by Location');
define('INFO_TEXT_SERCH_BY_CATEGORY','Search jobs by Industry');
define('INFO_TEXT_COMPANY_PROFILE','Search jobs by Companies');

define('INFO_TEXT_LIST_OF_COVER_LETTERS','My cover letters');
define('INFO_TEXT_LIST_OF_SAVED_SEARCHES','My saved searches');
define('INFO_TEXT_JOB_ALERT_AGENT','Job Alert Agent');
define('INFO_TEXT_CHANGE_PASSWORD','Change password');

define('INFO_TEXT_AVAILABILITY','Set status as available now');
define('STATUS_NOT_AVAILABLE', 'Set status as Not Available');
define('STATUS_NOT_AVAILABLITY', 'Not Available');
define('STATUS_AVAILABLE', 'Available');
define('STATUS_AVAILABLITY', 'Set status as available');
define('MESSAGE_SUCCESS_UPDATED_AVAILABLE', 'Success : You successfully set your resume status as <b>Available Now</b>.');
define('MESSAGE_SUCCESS_UPDATED_NOT_AVAILABLE', 'Success : Resume Status set to <b>NOT AVAILABLE</b>. Remember now your resumes are out of Search Engine.');
define('INFO_TEXT_NEWSLETTER','Newsletters');
define('INFO_TEXT_MY_MAILS','Response From Employers');
define('INFO_TEXT_CONTACT_LIST','Contact List');
define('INFO_TEXT_VIDEO_RESUME','Video Resume');
define('INFO_TEXT_LOGOUT','Logout');
define('INFO_TEXT_JOIN_FORUM','Join Forum');
define('INFO_TEXT_RESUME_STATISTICS','Resume Statistics');
define('INFO_TEXT_JOBSEEKER_ORDER_HISTORY','Order History');
define('INFO_TEXT_JOBS_BY_KEYWORD','Search jobs by Keyword');
?>