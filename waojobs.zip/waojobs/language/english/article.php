<?
define('HEADING_TITLE','Article');
define('ERROR_CATEGORY_NOT_EXIST','Error : Sorry, no Newsletter exists.');
define('TEXT_DISPLAY_NUMBER_OF_ARTICLES', 'Displaying <b>%d</b> to <b>%d</b> (of <b>%d</b> articles)');
define('INFO_TEXT_NEWSLETTER','Home');
define('INFO_TEXT_CATEGORY','Categories');
define('INFO_TEXT_EMAIL','Send to Friends');
define('INFO_TEXT_PRINT','Print this Article');
define('INFO_TEXT_MORE','More');
define('INFO_TEXT_SORRY_NO_ARTICLE','Sorry, no article exist.');
define('INFO_TEXT_BY','By');
define('INFO_TEXT_ARTICLE_BY_CATEGORY','Articles by Category');
define('INFO_TEXT_LATEST_ARTICLE','Latest Articles');
define('INFO_TEXT_PRINT_ARTICLE','Print Article');
define('INFO_TEXT_SORRY_NO_FILE_EXIST','Sorry, no file exist.');
?>