<?
define('HEADING_TITLE','Resume Upload');

define('REQUIRED_INFO','* Required information');
define('SECTION_ACCOUNT_RESUME_NAME','Resume name');

define('SECTION_DOCUMENT_UPLOAD','Resume');

define('INFO_TEXT_RESUME_NAME','Resume name :');
define('INFO_TEXT_UPLOAD_RESUME','Upload your resume:');
define('INFO_TEXT_UPLOAD_RESUME_HELP','Upload txt / doc / docx / pdf format');
define('INFO_TEXT_UPLOAD_PHOTO','Upload your photo:');
define('INFO_TEXT_UPLOAD_PHOTO_HELP','Upload gif / png / jpg format:');
define('INFO_TEXT_CUT_PASTE_CV','Cut & paste your resume here :');
define('INFO_TEXT_RESUME_DESCRIPTION','Description :');
define('INFO_TEXT_ADD_VIDEO','Add your youtube Video link :');

define('MESSAGE_SUCCESS_INSERTED','Success : Record successfully Inserted.');
define('MESSAGE_SUCCESS_UPDATED','Success : Record successfully Updated.');
define('MESSAGE_SUCCESS_DELETE','Success : Record successfully Deleted.');
define('MESSAGE_SUCCESS_PHOTO_DELETE','Success : photo successfully Deleted.');

define('IMAGE_UPDATE','Update');
define('IMAGE_SAVE_NEXT','save & goto next step');
define('IMAGE_RESET','Reset');
define('IMAGE_SAVE_ADD_NEW','save');
define('IMAGE_GO_TO_RESUME_LIST','Go to  resume list');
define('IMAGE_NEXT','Next >>');
define('INFO_TEXT_PLEASE_SELECT','Please select');
define('INFO_TEXT_RESUME_NAME','Resume name :');
define('INFO_TEXT_OBJECTIVE','Objective');
define('INFO_TEXT_TARGET_JOB','Target Job');
define('INFO_TEXT_TOTAL_WORK_EXP','Total Work Experience');
define('INFO_TEXT_YOUR_WORK_EXPERIENCE','Work Experience');
define('INFO_TEXT_LIST_OF_REFERENCES','List of References');
define('INFO_TEXT_EDUCATION_DETAILS','Education Details');
define('INFO_TEXT_YOUR_SKILLS','Skills');
define('INFO_TEXT_LANGUAGES','Languages');
define('INFO_TEXT_RESUME','Resume');
define('INFO_TEXT_PERSONAL_PROFILE','Personal Profile');
define('INFO_TEXT_EXPERIENCE','Experience');

define('INFO_TEXT_LEFT_RESUME','GENERAL INFORMATION');
define('INFO_TEXT_LEFT_EXPERIENCE','EXPERIENCE');
define('INFO_TEXT_LEFT_EDUCATION','EDUCATION');
define('INFO_TEXT_LEFT_SKILLS','SKILLS');
define('INFO_TEXT_LEFT_UPLOAD','UPLOAD');
define('INFO_TEXT_LEFT_REFERENCE','REFERENCES');
define('INFO_TEXT_LEFT_VIEW_RESUME','VIEW RESUME');
?>