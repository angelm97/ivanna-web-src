<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik#**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/
define('HEADING_TITLE', 'Applicant Interaction');
define('HEADING_FEADBACK_TITLE', 'Mail Feedback/Remark ');

define('INFO_TEXT_TO', 'To:');
define('INFO_TEXT_SUBJECT', 'Subject:');
define('INFO_MAIL_ATTACHMENT', 'Attachment :');
define('INFO_TEXT_FROM', 'From:');
define('INFO_TEXT_MESSAGE', 'Message:');
define('INFO_TEXT_REMARK', 'Remark Title:');
define('INFO_TEXT_DESCRIPTION', 'Description:');
define('TEXT_INFO_APPLICANT_OPRATION','Chose Your Action.');

define('MESSAGE_SUCCESS_SENT', 'Success: Message successfully sent.');
define('MESSAGE_SUCCESS_REMARK_SET', 'Success: feed back /remark  successfully save.');

define('TABLE_HEADING_INTERACTION_SUBJECT', 'Subject');
define('TABLE_HEADING_INTERACTION_INSERTED', 'Send');
define('TABLE_HEADING_INTERACTION_FEADBACK', 'Feedback/Remark');
define('TABLE_HEADING_INTERACTION_RECEIVED', 'Received');

define('INFO_TEXT_ALL_APPLICANT','All Applicants');
define('INFO_TEXT_SELECTED_APPLICANT','Selected Applicants');
define('INFO_TEXT_SEARCH_APPLICANT','Search Applicant');
define('INFO_TEXT_JOB_DETAIL','Job Detail');
define('INFO_TEXT_ADD_APPLICANT','Add/Import Applicant');
define('INFO_TEXT_REPORT_PIPELINE','Applicant Pipeline');
define('INFO_TEXT_REPORT_ROUNDWISE','Roundwise Report');
define('INFO_TEXT_REPORT_ROUNDWISE_SUMMARY','Roundwise Status Report');
define('INFO_TEXT_VIEW_DATE_REPORT',' Date wise Applied Applicants');
define('INFO_TEXT_DELETE',' Delete');


define('ERROR_APPLICATION_NOT_EXIST','Sorry this application doesnot exist. If problem persists please contact admin of the site.');
define('ENTRY_MESSAGE_ERROR',' Please enter message');
define('ENTRY_SUBJECT_ERROR', 'Please enter subject.');

define('IMAGE_EMAIL','E-mail');
define('IMAGE_SEND_MAIL', 'Send email');
define('IMAGE_PREVIEW_MAIL', 'Preview email');
define('IMAGE_BACK', 'Back');
define('IMAGE_CANCEL','Cancel');
define('IMAGE_PREVIEW','Preview');
define('IMAGE_ATTACHMENT','Attachment');
define('IMAGE_SUBMIT','Submit');
define('IMAGE_RATING','Rate Applicant');
define('IMAGE_REMARK','Remark');
define('IMAGE_PROFILE','View Resume');
define('IMAGE_CHANGE_STATUS','Edit Selection Round');
define('INFO_TEXT_SELECTION_HISTORY','View Selection History');
define('INFO_TEXT_ADD_COMMENT','Add Comment');
define('IMAGE_SELECTED','Select Applicant');
define('IMAGE_APPLICANT_SELECTION_RESET','Applicant Selection Reset');
define('IMAGE_SELECTED_APPLICATIONS','Selected Candidates');
define('IMAGE_CONTACT','Contact');
?>