<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','My applications');
define('TABLE_HEADING_JOB_REFERENCE','Job reference');
define('TABLE_HEADING_JOB_TITLE','Job Title');
define('TABLE_HEADING_JOB_INSERTED','Job inserted');
define('TABLE_HEADING_APPLICATION_STATUS','Applicant Status');
define('TABLE_HEADING_APPLICATION_INSERTED','Applied on');
define('TABLE_HEADING_APPLICATION_ID','Applicant ID');
define('TABLE_HEADING_APPLICATION_DELETE','Delete');
define('TABLE_HEADING_APPLICATION_REAPPLY','Re-apply');
define('ERROR_APPLICATION','Error : Sorry, this application does not exist.');
define('SUCCESS_APPLICATION_DELETED','success : This application successfully deleted.');
define('INFO_TEXT_APPLICATION','Application');
define('INFO_TEXT_APPLICATIONS','Applications');
define('INFO_TEXT_HAS_FOUND','has found');
define('INFO_TEXT_HAS_NOT_FOUND','has not found any applications.');
define('TABLE_HEADING_APPLIED_FOR','Company Name');
?>