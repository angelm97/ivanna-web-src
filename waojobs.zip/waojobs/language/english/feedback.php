<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Feedback');
define('INFO_TEXT_FULL_NAME','Full name : ');
define('INFO_TEXT_EMAIL_ADDRESS','E-Mail address : ');
define('INFO_TEXT_SUBJECT','Subject : ');
define('INFO_TEXT_MESSAGE','Message : ');
define('SUCCESS_EMAIL_SENT','Your message successfully sent.');
define('IMAGE_SEND','Send');
?>