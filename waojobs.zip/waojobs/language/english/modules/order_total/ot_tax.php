<?
  define('MODULE_ORDER_TOTAL_TAX_TITLE', 'Tax');
  define('MODULE_ORDER_TOTAL_TAX_DESCRIPTION', 'Order Tax');
?>