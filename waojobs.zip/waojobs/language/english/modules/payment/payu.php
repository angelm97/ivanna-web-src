<?php
/*
  

 oscMax

  
*/

  define('MODULE_PAYMENT_PAYU_TEXT_TITLE', 'PayUMoney Checkout');
  
?>