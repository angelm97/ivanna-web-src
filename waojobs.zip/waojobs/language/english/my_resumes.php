<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','My resumes');
define('TABLE_HEADING_RESUME_NAME', 'Resume name');
define('TABLE_HEADING_INSERTED', 'Inserted');
define('TABLE_HEADING_UPDATED', 'Updated');
define('TABLE_HEADINGVIEWED', 'Viewed');
define('TABLE_HEADING_EDIT', 'Edit');
define('TABLE_HEADING_DELETE', 'Delete');
define('TABLE_HEADING_VIEW', 'View');
define('TABLE_HEADING_DUPLICATE', 'Duplicate');

define('INFO_TEXT_EDIT', 'Edit');
define('INFO_TEXT_DELETE', 'Delete');
define('INFO_TEXT_VIEW', 'View');
define('INFO_TEXT_DUPLICATE', 'Duplicate');

define('MESSAGE_SUCCESS_UPDATED', 'Success : Resume successfully updated.');
define('MESSAGE_SUCCESS_DELETED', 'Success : Resume successfully deleted.');
define('MESSAGE_SUCCESS_DUPLICATED', 'Success : Resume successfully duplicated.');
define('INFO_TEXT_MAX_RESUME', 'Note : You can create upto <b>%d</b> resumes.');
define('TABLE_HEADING_SEARCHABLE', 'Searchable?');

define('STATUS_RESUME_NOT_SEARCH', 'Not searchable');
define('STATUS_RESUME_NOT_SEARCHABLE', 'Not searchable?');

define('STATUS_RESUME_SEARCH', 'Searchable');
define('STATUS_RESUME_SEARCHABLE', 'Searchable?');

define('TABLE_HEADING_AVAILABILITY', 'Available?');
define('STATUS_NOT_AVAILABLE', 'Not Available');
define('STATUS_NOT_AVAILABLITY', 'Not Available?');

define('STATUS_AVAILABLE', 'Available');
define('STATUS_AVAILABLITY', 'Available?');
define('NOT_ACTIVATION_ERROR', 'To meke your cv searchable, please go to registration page (Edit Profile) and make "My Resume is searchable? Yes"');
define('INFO_TEXT_ADD_NEW_RESUME','Add new resume');
?>