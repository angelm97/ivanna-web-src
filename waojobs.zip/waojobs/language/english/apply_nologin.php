<?
define('HEADING_TITLE','Apply Without Login');
define('INFO_TEXT_NAME','Name : ');
define('INFO_TEXT_EMAIL','E-Mail : ');
define('INFO_TEXT_SUBJECT','Subject : ');
define('INFO_TEXT_UPLOAD_RESUME','Upload Resume : ');

define('ERROR_RESUME_NOT_EXIST','Error : you must add your resume first.');
define('ERROR_JOB_NOT_EXIST','Error : Sorry this job does not exist or deleted from our database.');
define('INFO_TEXT_CV','Attach your CV : ');
define('ERROR_RESUME_SEND','Error : Please select resume to upload.');
define('ENTER_NAME_ERROR','Error: Please enter Name');
define('ENTER_EMAIL_ERROR','Error: Please enter Email Address');
define('MESSAGE_SUCCESS_APPLED','Thank you for applying! Here are some other jobs nearby that may interest you.');
define('SUCCESS_RESUME_SEND','Resume send successfully.');
////
define('IMAGE_CONFIRM','Apply now');
define('INFO_TEXT_MESSAGE','Message');
define('INFO_TEXT_UPLOAD_RESUME_HELP','Upload txt / doc / docx / pdf format');
define('CAPTCHA_ERROR_1','Please select file to upload');
define('INFO_TEXT_SECURITY_CODE','Security Code :');
define('INFO_TEXT_TYPE_CODE','Type the code shown');
define('ERROR_SECURITY_CODE','Error: Invalid Security Code .');
?>