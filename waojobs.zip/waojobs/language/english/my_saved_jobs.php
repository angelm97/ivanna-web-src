<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', 'List of saved jobs');
//////////////////////////
define('TABLE_HEADING_JOB_TITLE', 'Job title');
define('TABLE_HEADING_COMPANY_NAME', 'Company name');
define('TABLE_HEADING_ADVERTISED', 'Advertised on');
define('TABLE_HEADING_EXPIRED', 'Expired on');
define('TABLE_HEADING_DELETE', 'Delete');
define('TABLE_HEADING_APPLY', 'Apply');

define('MESSAGE_SUCCESS_DELETED','Success: Saved job successfully deleted.');

define('MESSAGE_JOB_ERROR','Sorry this job doesnot exist. If problem persists please contact admin of the site.');
define('INFO_TEXT_APPLY_NOW','apply now');
?>