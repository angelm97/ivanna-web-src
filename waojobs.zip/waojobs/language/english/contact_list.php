<?
define('HEADING_TITLE','Contact List');
define('HEADING_TITLE1','Add Contact');
define('TABLE_HEADING_USER_NAME','Name');
define('TABLE_HEADING_ADDRESS','Address');
define('TABLE_HEADING_EDIT','Edit');
define('TABLE_HEADING_DELETE','Delete');

define('INFO_TEXT_FIRST_NAME','First Name :');
define('INFO_TEXT_MIDDLE_NAME','Middle Name :');
define('INFO_TEXT_LAST_NAME','Last Name :');
define('INFO_TEXT_EMAIL_ADDRESS','E-Mail Address :');
define('INFO_TEXT_ADDRESS1','Home Address1 :');
define('INFO_TEXT_ADDRESS2','Home Address2 :');
define('INFO_TEXT_COUNTRY','Country :');
define('INFO_TEXT_STATE','State/Province :');
define('INFO_TEXT_CITY','City/Town :');
define('INFO_TEXT_ZIP','Zip Code :');
define('INFO_TEXT_HOME_PHONE','Phone Number : ');
define('INFO_TEXT_MOBILE','Mobile/Cell : ');

define('FIRST_NAME_ERROR', 'Your have to filled up First Name.');
define('ENTRY_STATE_ERROR_SELECT', 'Please select a state from the States pull down menu.');
define('MESSAGE_SUCCESS_UPDATED','Contact list  successfully updated.');
define('MESSAGE_SUCCESS_INSERTED','user successfully inserted in your contact list.');
define('MESSAGE_SUCCESS_DELETED','user successfully deleted in your contact list.');

define('IMAGE_INSERT','Insert');
define('IMAGE_NEXT','Next >>');
define('IMAGE_ADD','Add');
?>