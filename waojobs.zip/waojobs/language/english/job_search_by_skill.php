<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #******
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2017  #**********
**********************************************************/


if(isset($_GET['Skill']))
define('HEADING_TITLE','%s  Jobs');
else
define('HEADING_TITLE','Job Search By Skills');
define('INFO_TEXT_JOB_CATEGORY','Job Category :');


define('INFO_TEXT_LOCATION','Location');
define('INFO_TEXT_EXPERIENCE','Experience');
define('INFO_TEXT_JOB_POSTED','	Show me jobs posted within : ');
define('INFO_TEXT_DEFAULT_JOB_POST_DAY','All');


define('INFO_TEXT_COMPANY_NAME','Company ');
define('INFO_TEXT_LOCATION_NAME','Location');
define('INFO_TEXT_POSTED_ON','Posted On :');
define('INFO_TEXT_SALARY','Salary');
define('INFO_TEXT_SALARY_DOT',':');
define('INFO_TEXT_APPLY_BEFORE','Apply Before :');
define('INFO_TEXT_JOB_SKILL','Job Skills');

define('INFO_TEXT_APPLY_NOW','Apply Now ! ');
define('INFO_TEXT_APPLY_NOW1','Apply to multiple jobs by selecting jobs of your choice.');

define('MESSAGE_ERROR_SAVED_SERCH_NOT_EXIST','Error: Sorry, this saved search does not exist.');
define('MESSAGE_ERROR_SAVED_SERCH_ALREADY_EXIST','Error: Sorry, this saved search name already exists.');
 
define('IMAGE_SEARCH','Search');
define('IMAGE_SAVE','Save search');
define('IMAGE_CANCEL','Cancel');
define('IMAGE_BACK','Back');
define('IMAGE_APPLY','Apply now');
define('INFO_TEXT_CLICK_HERE_TOSEE_DETAILS','click here to see details');
define('INFO_TEXT_HAS_MATCHED','has matched');
define('INFO_TEXT_TO_YOUR_SEARCH_CRITERIA','to your search criteria.');
define('INFO_TEXT_JOB','Job');
define('INFO_TEXT_JOBS','Jobs');
define('INFO_TEXT_HAS_NOT_MATCHED','has not matched any Job to your search criteria.');
define('INFO_TEXT_ALL_JOB_CATEGORY','All Job categories...');
define('INFO_TEXT_ALL_COUNTRIES','All countries');
define('INFO_TEXT_DESCRIPTION','Job Description :');
define('INFO_TEXT_EMAIL_THIS_JOB','Email This Job');
define('MORE_DETAILS','More Details');
define('INFO_TEXT_APPLY_TO_THIS_JOB','Apply to this Job');
?>