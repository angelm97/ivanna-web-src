<?
define('HEADING_TITLE','Apply now');
define('HEADING_SECTION','Complete all the appropriate sections and submit your application.');

define('INFO_TEXT_TO','To : ');
define('INFO_TEXT_FROM','From : ');
define('INFO_TEXT_EMAIL','E-Mail : ');
define('INFO_TEXT_SUBJECT','Subject : ');
define('INFO_TEXT_COVER_LETTER','Your cover letter : ');
define('INFO_TEXT_RESUMES','Your resume : ');
define('INFO_TEXT_VIEW_CV_LINK','To view my CV, Please click the following link.%s');

define('ERROR_RESUME_NOT_EXIST','Error : you must add your resume first.');
define('ERROR_JOB_NOT_EXIST','Error : Sorry this job does not exist or deleted from our database.');
define('INFO_TEXT_CV','Attach your CV : ');
define('INFO_TEXT_DEFALUT_COVER_LETTER',' I found your position posted at '.SITE_TITLE.' and I am interested in applying for the above referenced position and attach my resume accordingly.');
define('INFO_TEXT_DEFALUT_COVER_LETTER1',' [ The above cover letter is default. If you would like to change the text, please delete it and add your own OR create your own cover letter in your control panel to be attached automatically to all applications. ] %s');

define('MESSAGE_SUCCESS_APPLED','Thank you for applying! Here are some other jobs nearby that may interest you.');

////
define('IMAGE_CONFIRM','Apply now');
define('INFO_TEXT_CANDIDATE_RESPOND','The candidate has respond positively to');
define('INFO_TEXT_QUALIFICATION_QUESTIONS','qualification questions.');
define('INFO_TEXT_APPLICANT_TRACKING','Applicant Tracking Jobsite application -');
define('INFO_TEXT_SCREENER','Screener');
define('INFO_TEXT_QUESTION','Question');
define('INFO_TEXT_ANSWER','Answer-');
define('INFO_TEXT_NOT_ADDED_YET','Not added yet.');
define('INFO_TEXT_ADD_NEW_RESUME','Add new resume ?');
define('INFO_TEXT_ADD_NEW_COVER_LETTER','Add new cover letter ?');
define('INFO_TEXT_VIEW_RESUME','View Resume');
define('INFO_TEXT_JOB_TITLE','Job Title');
?>