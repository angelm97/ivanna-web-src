<?
define('HEADING_TITLE', 'Forum');
define('INFO_TEXT_HEADING_SEARCH','Search');

define('INFO_TEXT_SORRY_NO_TOPICS','No forum topics available.Be the First one to add a topic');
define('IMAGE_NEW','Create New Thread');
define('INFO_TEXT_TITLE','Title:');
define('INFO_TEXT_DESCRIPTION','Description:');
define('MESSAGE_SUCCESS_INSERTED','Topic successfully posted');

define('MESSAGE_INVALID_FORUM_ERROR','invalid forum topic.');
define('ERROR_ARTICLE_TITLE','Please enter Title.');
define('ERROR_ARTICLE_DESCRIPTION','Please enter description.');
define('IMAGE_BACK','Back');
define('IMAGE_SAVE','Save');
define('IMAGE_PREVIEW','Preview');
define('INFO_TEXT_HOME','Home');
?>
