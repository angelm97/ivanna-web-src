<?
define('HEADING_TITLE', 'Forum');
define('TEXT_INFO_THREADS', 'Threads');
define('TEXT_INFO_POSTS', 'Posts');
define('INFO_TEXT_HOME','Home');
define('INFO_TEXT_HEADING_SEARCH','Search');
?>
