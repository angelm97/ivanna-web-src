<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft Pvt. Ltd.   #**********
**********# Copyright (c) www.aynsoft.com 2005  #**********
**********************************************************/
//*
define('DB_SERVER', 'localhost');
define('DB_SERVER_USERNAME', 'root');
define('DB_SERVER_PASSWORD', '');
define('DB_DATABASE', 'waojobs');
define('USE_PCONNECT', 'false');
//*/
/*
define('DB_SERVER', 'localhost');
define('DB_SERVER_USERNAME', 'username');
define('DB_SERVER_PASSWORD', 'password');
define('DB_DATABASE', 'database_name');
define('USE_PCONNECT', 'true');
*/
?>