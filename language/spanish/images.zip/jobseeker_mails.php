<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik#**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/
define('HEADING_TITLE', 'Respuesta de las empresas');

define('INFO_TEXT_SUBJECT', 'Asunto:');
define('INFO_MAIL_ATTACHMENT', 'Adjunto archivo :');
define('INFO_TEXT_DESCRIPTION', 'Descripción:');
define('INFO_TEXT_MESSAGE', 'Mensaje:');


define('TABLE_HEADING_MAIL_SENDER', 'Remitente');
define('TABLE_HEADING_APPLICATION_ID', 'ID de aplicación');
define('TABLE_HEADING_MAIL_SUBJECT', 'Asunto');
define('TABLE_HEADING_MAIL_INSERTED', 'Fecha');

define('ERROR_MAIL_NOT_EXIST','¡Oops! El correo no existe. Si no puedes ingresar, el Equipo WaoJobs está para ayudarte, escríbenos AQUÍ.');
define('MESSAGE_SUCCESS_MARKED','¡Listo! Tu correo se marcó correctamente');
define('MESSAGE_SUCCESS_DELETED','¡Listo! Tu correo se borró ');
define('MESSAGE_SUCCESS_RESTORE','Your mail successfully  restore in inbox');
define('MESSAGE_SUCCESS_UNMARKED','¡Listo! Tu correo se eliminó ');
define('REPLY_SUCCESS_SENT','Éxito: repetición enviada con éxito');
define('ENTRY_MESSAGE_ERROR','Por favor ingrese el mensaje');
define("INFO_TEXT_REPLY","Respuesta");


define('IMAGE_BACK', 'Atrás');
define('IMAGE_ATTACHMENT','Adjunto archivo');
define('INFO_TEXT_VIEW_IN','Ver en ');
define('INFO_TEXT_VIEW_TRASH',' Basura');
define('INFO_TEXT_VIEW_INBOX','Bandeja de entrada');
define('INFO_TEXT_VIEW_SEND','Send');
define('INFO_TEXT_VIEW_IN','Ver en');
define('INFO_TEXT_ALL','Todas');
define('INFO_TEXT_SHOW_ALL','Mostrar todo');
define('INFO_TEXT_UNREAD','No leído');
define('INFO_TEXT_INBOX','Bandeja de entrada');
define('INFO_TEXT_TRASH','Basura');
define('INFO_TEXT_MARKED','Marcado');
define('INFO_TEXT_MAIL','Correo');
define('INFO_TEXT_MAILS','Correos');
define('INFO_TEXT_HAS_FOUND','has encontrado');
define('INFO_TEXT_CHECK_ALL','Comprobar todo');
define('INFO_TEXT_UNCHECK_ALL','Desmarcar todo');
define('INFO_TEXT_WITH_SELECTED','Con selección');
define('INFO_TEXT_CLEAR_MARK','Borrar las marcas');
define('INFO_TEXT_DELETE','Borrar');
define('INFO_TEXT_RESTORE','Restaurar');
define('INFO_TEXT_HAS_NOT_FOUND','No se ha encontrado ningún correo');
?>