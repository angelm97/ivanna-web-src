<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Términos y condiciones');
define('INFO_TEXT_CONTENT','
<P class=MsoNormal style="MARGIN: 0in 0in 0pt">En construcción</P>
');
?>