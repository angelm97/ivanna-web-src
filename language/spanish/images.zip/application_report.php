<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik#**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/

define('HEADING_TITLE', 'Informes');
define('HEADING_TITLE_PIPELINE', 'Filtro de candidatos');
define('HEADING_TITLE_ROUNDWISE','Informes de Round Wise');

define('TABLE_HEADING_TITLE', 'Fecha sabia solicitantes aplicadas');
define('TABLE_HEADING_TITLE1', 'Ronda de aplicantes/Reporte de Status' );
define('TABLE_HEADING_DATE', 'Fecha');
define('TABLE_HEADING_APPLICATION', 'Aplicación insertada ');
define('TABLE_HEADING_SELECTED_APPLICATION', 'Aplicación seleccionada');
define('TABLE_HEADING_ROUND_STATUS','Ronda \ Estado -->');
define('TABLE_HEADING_NEW','Nuevo');
define('TABLE_HEADING_TOTAL','Total');
define('TABLE_HEADING_PROCESS','En proceso');
define('TABLE_HEADING_REJECT','Rechazado');
define('TABLE_HEADING_SELECT','Aprobado');
define('TABLE_HEADING_WAITING','Esperando');
define('INFO_TEXT_BACK', 'Atrás');

define('INFO_TEXT_ALL_APPLICANT','Todos los candidatos');
define('INFO_TEXT_SELECTED_APPLICANT','Candidatos seleccionados');
define('INFO_TEXT_SEARCH_APPLICANT','Buscar candidatos');
define('INFO_TEXT_JOB_DETAIL','Detalles de la oportunidad laboral');
define('INFO_TEXT_ADD_APPLICANT','Agregar / importar candidato');
define('INFO_TEXT_REPORT_PIPELINE','Listado de candidatos');
define('INFO_TEXT_REPORT_ROUNDWISE','Reporte');
define('INFO_TEXT_REPORT_ROUNDWISE_SUMMARY','Informe de estado de Roundwise');
define('INFO_TEXT_VIEW_DATE_REPORT','Fecha sabia solicitantes aplicadas');

define('INFO_TEXT_JOB_LISTING', 'Listado de oportunidades laborales');
define('INFO_TEXT_APPLICATION', 'Solicitud');
define('INFO_TEST_HEADER_SUMMERY', 'Resumen');

define('INFO_TEXT_FROM_DATE', 'De :');
define('INFO_TEXT_TO_DATE', 'Para :');
define('IMAGE_GO', 'Ir');
define('INFO_TEXT_ROUND', 'Ronda');
define('INFO_TEXT_SELECTED', 'Seleccionado');
define('INFO_TEXT_JOINED', 'Unido');
define('INFO_TEXT_DECLINED', 'Rechazado');
define('INFO_TEXT_TOTAL', 'Total');

?>