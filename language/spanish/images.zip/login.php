<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE1','Soy Talento');
define('AUTO_LOGIN1','Recuérdame');
define('FACEBOOK_USER_RECRUITER_ERROE1','¡Oops! Tu dirección de correo electrónico registe como empresa, por lo tanto, no te deja ingresar como talento.');
define('INFO_TEXT_FORGOT_PASSWORD1','¿Olvidaste tu contraseña?');
define('INFO_TEXT_NEW_USER1','¿Aún no tienes una cuenta?');
define('INFO_TEXT_REGISTER_NOW1','¡Regístrate ahora!');


define('HEADING_TITLE2','Soy Empresa');
define('AUTO_LOGIN2','Recuérdame');
define('FACEBOOK_USER_JOBSEEKER_ERROE2','¡Oops! Tu dirección de correo electrónico registe como talento, por lo tanto, no te deja ingresar como empresa.');
define('INFO_TEXT_NEW_USER2','¿Aún no tienes una cuenta?');
define('INFO_TEXT_REGISTER_NOW2','¡Regístrate ahora!');
define('INFO_TEXT_FORGOT_PASSWORD2','¿Olvidaste tu contraseña?');

define('SORRY_LOGIN_MATCH','¡Oops! Tu dirección de correo electrónico o contraseña parece ser incorrecta, inténtalo de nuevo.');
define('SIGN_IN','Iniciar sesión');
define('INTO_LOG_IN','INICIAR SESIÓN');
define('INFO_LOGIN_WITH','O inicia sesión con ');
define('INFO_NO_ACCOUNT','¿Aún no tienes una cuenta?');
?>