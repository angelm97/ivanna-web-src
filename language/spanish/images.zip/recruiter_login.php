<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Reclutador Iniciar sesión aquí');

define('INFO_TEXT_EMAIL_ADDRESS','Dirección de correo electrónico:');
define('INFO_TEXT_PASSWORD','Contraseña:');

define('IMAGE_CONFIRM','Confirmar');
define('AUTO_LOGIN','Habilitar inicio de sesión automático');
define('SORRY_LOGIN_MATCH','¡Oops! Tu dirección de correo electrónico o contraseña parece ser incorrecta, inténtalo de nuevo.');
define('FACEBOOK_USER_JOBSEEKER_ERROE','¡Oops! Tu dirección de correo electrónico nos registra como usuario de Candidato, no puedes usar la misma como Reclutador.');
define('INFO_TEXT_NEW_USER','¿Nuevo usuario?');
define('INFO_TEXT_CLICK_HERE','Haz clic aquí');
define('INFO_TEXT_REGISTER_NOW','¡Regístrate ahora!');
define('INFO_TEXT_FORGOT_PASSWORD','¿Olvidaste tu contraseña?');
define('INFO_TEXT_EMAIL_PASSWORD','Enviaremos tu contraseña por correo electrónico.');
define('INFO_TEXT_ALREADY_MEMBER','¿Ya eres usuario?');
define('INFO_TEXT_LOGIN','Acceso');
define('INFO_TEXT_QUOT1','Publicar oportunidades laborales por categoría');
define('INFO_TEXT_QUOT2','Ver, guardar & amp; organizar hojas de vida en línea');
define('INFO_TEXT_QUOT3','Obtener hojas de vida por correo electrónico como alerta');
define('INFO_TEXT_QUOT4','Haz un seguimiento de los candidatos, filtra y realiza el proceso de selección en línea');

?>