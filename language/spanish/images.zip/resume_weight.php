<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/
define('HEADING_TITLE','Reanudar peso');

define('INFO_TEXT_FIELDS','Campos');
define('INFO_TEXT_WEIGHTS','Pesos (%)');
define('INFO_TEXT_LOCATION','Localización');
define('INFO_TEXT_INDUSTRY','Industria ');
define('INFO_TEXT_JOB_TYPE','Tipo de empleo');
define('INFO_TEXT_EXPERIENCE','Experiencia');
define('INFO_TEXT_TOTAL','Total :');
define('TOTAL_EXCEED_ERROR','¡Oops! El peso total no supera los 100.');
define('TOTAL_BELOW_ERROR','¡Oops! El peso total no es inferior a 100.');
define('MESSAGE_SUCCESS_SAVE','¡Listo! Reanudar el peso guardado correctamente.');
define('ERROR_JOB_NOT_EXIST','¡Oops! Este trabajo no existe.');
define('IMAGE_SAVE','Ahorrar');
?>