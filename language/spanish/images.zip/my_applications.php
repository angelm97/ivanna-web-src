<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Mis aplicaciónes');
define('TABLE_HEADING_JOB_REFERENCE','Referencia laboral');
define('TABLE_HEADING_JOB_TITLE','Título profesional');
define('TABLE_HEADING_JOB_INSERTED','Trabajo insertado');
define('TABLE_HEADING_APPLICATION_STATUS','Estado del candidato');
define('TABLE_HEADING_APPLICATION_INSERTED','Aplicado en');
define('TABLE_HEADING_APPLICATION_ID','ID del candidato');
define('TABLE_HEADING_APPLICATION_DELETE','Borrar');
define('TABLE_HEADING_APPLICATION_REAPPLY','Aplicar de nuevo');
define('ERROR_APPLICATION','¡Oops! Esta aplicación no existe.');
define('SUCCESS_APPLICATION_DELETED','success : ¡Listo! Esta aplicación se eliminó correctamente.');
define('INFO_TEXT_APPLICATION','Solicitud');
define('INFO_TEXT_APPLICATIONS','Aplicaciones');
define('INFO_TEXT_HAS_FOUND','has encontrado');
define('INFO_TEXT_HAS_NOT_FOUND','no has encontrado ninguna aplicación.');
?>