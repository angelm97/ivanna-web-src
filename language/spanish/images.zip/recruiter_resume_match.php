<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/
define('HEADING_TITLE','Reanudar el nivel de coincidencia');

define('INFO_TEXT_FIELDS','Campos');
define('INFO_TEXT_JOB_WEIGHTS','Pesos de trabajo');
define('INFO_TEXT_RESUME_WEIGHTS','Reanudar partido');
define('INFO_TEXT_JOBSEEKER_APP_ID','ID de aplicación:');
define('INFO_TEXT_LOCATION','Ubicación');
define('INFO_TEXT_INDUSTRY','Industria ');
define('INFO_TEXT_JOB_TYPE','Tipo de oportunidad laboral');
define('INFO_TEXT_EXPERIENCE','Experiencia');
define('INFO_TEXT_TOTAL','Total :');

define('ERROR_JOB_NOT_EXIST','¡Oops! Esta oportunidad laboral no se encuentra.');
define('ERROR_RESUME_NOT_EXIST','¡Oops! Esta hoja de vida no se encuentra.');
?>