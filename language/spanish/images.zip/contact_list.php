<?
define('HEADING_TITLE','Lista de contactos');
define('HEADING_TITLE1','Agregar contacto');
define('TABLE_HEADING_USER_NAME','Nombre de usuario');
define('TABLE_HEADING_ADDRESS','Dirección');
define('TABLE_HEADING_EDIT','Editar');
define('TABLE_HEADING_DELETE','Borrar');

define('INFO_TEXT_FIRST_NAME','Primer nombre :');
define('INFO_TEXT_MIDDLE_NAME','Segundo nombre :');
define('INFO_TEXT_LAST_NAME','Apellido :');
define('INFO_TEXT_EMAIL_ADDRESS','Dirección de correo electrónico :');
define('INFO_TEXT_ADDRESS1','Dirección de casa  :');
define('INFO_TEXT_ADDRESS2','Dirección de casa  :');
define('INFO_TEXT_COUNTRY','País :');
define('INFO_TEXT_STATE','Estado/Provincia :');
define('INFO_TEXT_CITY','Ciudad :');
define('INFO_TEXT_ZIP','Código postal :');
define('INFO_TEXT_HOME_PHONE','Número de teléfono : ');
define('INFO_TEXT_MOBILE','Celular : ');

define('FIRST_NAME_ERROR', 'Debes completar tu nombre.');
define('ENTRY_STATE_ERROR_SELECT', 'Selecciona un estado.');
define('MESSAGE_SUCCESS_UPDATED','¡Listo! Lista de contactos actualizada.');
define('MESSAGE_SUCCESS_INSERTED','¡Listo! Usuario agregado a tu lista de contactos.');
define('MESSAGE_SUCCESS_DELETED','user successfully deleted in your contact list.');

define('IMAGE_INSERT','Insertar');
define('IMAGE_NEXT','Próximo >>');
define('IMAGE_ADD','Agregar');
?>