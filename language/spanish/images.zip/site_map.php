<?
define('HEADING_TITLE','Mapa del sitio');
define('INFO_TEXT_LOGIN','Acceso');
define('INFO_POST_RESUME','Publicar hojas de vida');
define('INFO_TEXT_SEARCH_JOBS','Buscar oportunidades laborales');
define('INFO_TEXT_BY_CATEGORY','Buscar trabajo por categoría');
define('INFO_TEXT_BY_LOCATION','Buscar trabajo por ubicación');
define('INFO_TEXT_BY_COMPANY','Buscar trabajo por empresa');
define('INFO_TEXT_ADVANCE_SEARCH','Búsqueda avanzada');
define('INFO_TEXT_CAREER_ADVICE','¡Quisiera orientación profesional!');
define('INFO_TEXT_INVITE_FIRENDS','Invitar amigos');
define('INFO_TEXT_POST_JOBS','Publicar oportunidades laborales');
define('INFO_TEXT_SEARCH_RESUMES','Búsqueda de hojas de vida');
define('INFO_TEXT_RATES','Tarifas');
define('INFO_TEXT_VIEW_RESUME_TO_JOB','Ver hojas de vida de tu trabajo');
define('INFO_TEXT_COMPARE_RESUMES','Compara dos hojas de vida');
define('INFO_TEXT_IMPORT_MULTIPLE_JOBS','Importar varios trabajos');
define('INFO_TEXT_SAVE_RESUME','Guardar hoja de vida');
define('INFO_TEXT_LIST_OF_JOBS','Lista de oportunidades laborales');
define('INFO_TEXT_ACTIVE_JOBS','Oportunidades laborales activas');
define('INFO_TEXT_EXPIRED_JOBS','Oportunidades laborales caducadas');
define('INFO_TEXT_DELETED_JOBS','Oportunidades laborales eliminadas');
define('INFO_TEXT_SORT_RESUME','Ordene las hojas de vida apropiadas para su oportunidad laboral');
define('INFO_TEXT_ROUNDWISE_REPORT','Ver informe general de candidato');
define('INFO_TEXT_HOME','Inicio');
define('INFO_TEXT_ABOUT_US','¿Quiénes somos?');
define('INFO_TEXT_FAQS','Preguntas frecuentes ');
define('INFO_TEXT_JOB_SEEKER_FAQS','Preguntas frecuentes de candidatos');
define('INFO_TEXT_EMPLOYER_FAQS','Preguntas frecuentes de empresas');
define('INFO_TEXT_RSS_BY_CATEGORY','RSS por categoría de trabajo');
define('INFO_TEXT_RSS_ALL_JOBS','RSS de todas las oportunidades laborales');
define('INFO_TEXT_NEWSLETTER','Inscríbete al boletín');
define('INFO_TEXT_NEWS','Noticias');
define('INFO_TEXT_ADVERTISE_WITH_US','Publicidad con nosotros');
define('INFO_TEXT_TERMS','Condiciones de uso');
define('INFO_TEXT_PRIVACY','Política de privacidad');
define('INFO_TEXT_Contact_Us','Contáctanos');
define('INFO_TEXT_SITEMAP','Mapa del sitio');
define('INFO_TEXT_EMPLOYERS','Empresas');
define('INFO_TEXT_JOBSEEKERS','Talentos');
define('INFO_TEXT_EMPLOYER','Empresas');
define('INFO_TEXT_OTHERS','Otros');
define('INFO_TEXT_SERVICES','Servicios');


?>