<?
define('HEADING_TITLE','Regalo');
define('INFO_TEXT_AMOUNT','Monto adeudado - %s');
define('IMAGE_BUTTON_NEXT','Siguiente >>');
define('IMAGE_BUTTON_CHANGE_ORDER','Cambia el orden');
?>