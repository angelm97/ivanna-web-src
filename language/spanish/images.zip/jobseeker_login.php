<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Solicitante de empleo Inicie sesión aquí');

define('INFO_TEXT_EMAIL_ADDRESS','Dirección de correo electrónico :');
define('INFO_TEXT_PASSWORD','Contraseña :');

define('IMAGE_CONFIRM','Confirmar');
define('AUTO_LOGIN','Habilitar inicio de sesión automático');
define('SORRY_LOGIN_MATCH','¡Oops! Tu dirección de correo electrónico o contraseña parece ser incorrecta. Inténtalo de nuevo.');
define('FACEBOOK_USER_RECRUITER_ERROE','¡Oops! Tu dirección de correo electrónico nos registra como reclutador.');
define('INFO_TEXT_ALREADY_MEMBER','¿Ya eres usuario?');
define('INFO_TEXT_LOGIN','Acceso');
define('INFO_TEXT_1','Buscar oportunidades laborales por ubicación, categoría y empresa');
define('INFO_TEXT_2','Envía tu hoja de vida a cualquier empleador con un solo clic');
define('INFO_TEXT_3','Ver la frecuencia con la que los empleadores vieron tu hoja de vida');
define('INFO_TEXT_4','Recibe correo del empleador con respecto a la entrevista');
define('INFO_TEXT_CLICK_HERE','Haz clic aquí');
define('INFO_TEXT_FORGOT_PASSWORD','Haz olvidado tu contraseña');
define('INFO_TEXT_NEW_USER','Nuevo usuario');
define('INFO_TEXT_REGISTER_NOW','¡Regístrate ahora!');
?>