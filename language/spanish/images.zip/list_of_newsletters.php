<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Boletin informativo');
define('TABLE_HEADING_TITLE', 'Título');
define('TABLE_HEADING_INSERTED', 'Fecha');
define('TABLE_HEADING_VIEW', 'Vista');
define('INFO_TEXT_ATTACHMENT_DOWNLOAD','Descarga de archivos adjuntos');
define('INFO_TEXT_NEWSLERRERS','Boletines');
define('INFO_TEXT_NO_NEWSLETTER_AVAILABLE','No hay boletín disponible');
?>