<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Envía un correo electrónico a tu amigo');
define('SUCCESS_EMAIL_SENT','Your message successfully sent to your friend.');
define('INFO_TEXT_FROM_NAME','Tu nombre completo:');
define('INFO_TEXT_FROM_EMAIL_ADDRESS','Tu dirección de correo electrónico :');
define('INFO_TEXT_TO_NAME','Your friend\'s full name : ');
define('INFO_TEXT_TO_EMAIL_ADDRESS','Nombre completo de tu amigo:');
define('INFO_TEXT_SUBJECT','Título del artículo: ');
define('INFO_TEXT_URL','URL : ');
define('IMAGE_SEND','Enviar');
define('NO_ARTICLE','¡Oops! No hay ningún artículo para enviar');
define('INFO_TEXT_NEWSLETTER','Inicio');
define('INFO_TEXT_CATEGORY','Categorías');
define('INFO_TEXT_CLICK_HERE','Haz clic aquí');
define('INFO_TEXT_HI','¡Hola!');
define('INFO_TEXT_YOUR_FRIEND','Tu amigo');
define('INFO_TEXT_INTERESTING_ARTICLE','te ha enviado un artículo interesante para ti, ¿te gustaría leerlo?');
define('INFO_TEXT_EMAIL_ADDRESS','La dirección de correo electrónico es');
define('INFO_TEXT_MESSAGE_AS','El mensaje es el siguiente ...');
define('INFO_TEXT_ARTICLE','Artículo');
define('INFO_TEXT_ARTICLE_FROM','Artículo de');
define('INFO_TEXT_HOME','Inicio');
define('INFO_TEXT_Q_A','Preguntas y Respuestas');
define('YOUR_NAME_ERROR','Por favor, escribe tu nombre.');
define('YOUR_EMAIL_ADDRESS_ERROR','Ingresa tu dirección de correo electrónico.');
define('YOUR_FRIEND_NAME_ERROR','Ingresa el nombre de tu amigo.');
define('YOUR_FRIEND_EMAIL_ADDRESS_ERROR','Ingresa la dirección de correo electrónico de tu amigo.');
?>