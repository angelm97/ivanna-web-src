<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', 'Carta de presentación');
//////////////////////////
define('IMAGE_CANCEL','Cancelar');
define('INFO_TEXT_CLOSE','Cerrar');
?>