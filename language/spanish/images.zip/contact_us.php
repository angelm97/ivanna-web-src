<?
define('HEADING_TITLE','Formulario de contacto: ¡Escríbenos!');
define('INFO_TEXT_FULL_NAME','Nombre completo: Tu nombre : ');
define('INFO_TEXT_EMAIL_ADDRESS','Dirección de correo electrónico : ');
define('INFO_TEXT_SUBJECT','Asunto : ');
define('INFO_TEXT_MESSAGE','Mensaje : ');
define('SUCCESS_EMAIL_SENT','¡Listo! Tu mensaje ha sido enviado.');
define('IMAGE_SEND','Enviar');
define('FIRST_PARAGRAPH','<p>El equipo WaoJobs está para apoyarte, escríbenos: El Equipo WaoJobs está para apoyarte.</p>');
define('YOUR_NAME_ERROR','Por favor, escribe tu nombre.');
define('YOUR_EMAIL_ADDRESS_ERROR','Por favor, introduce tu dirección de correo electrónico.');
define('EMAIL_SUBJECT_ERROR','Ingresa el asunto del correo electrónico.');
define('EMAIL_MESSAGE_ERROR','Ingresa el mensaje de correo electrónico.');
define('INFO_TEXT_SECURITY_CODE','Código de seguridad :');
define('INFO_TEXT_TYPE_CODE','Escribe el código mostrado');
define('ERROR_SECURITY_CODE','¡Oops! Revisa tu código de seguridad, este no es válido.');

?>