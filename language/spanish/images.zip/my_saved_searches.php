<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', 'Mis búsquedas guardadas / Agente de alerta de empleo');
//////////////////////////
define('TABLE_HEADING_RUN', 'Correr');
define('TABLE_HEADING_EDIT', 'Editar');
define('TABLE_HEADING_DELETE', 'Borrar');
define('TABLE_HEADING_INSERT_DATE', 'Insertado');
define('TABLE_HEADING_UPDATE_DATE', 'Actualizado');
define('TABLE_HEADING_TITLE_NAME', 'Nombre del título');
define('MESSAGE_SUCCESS_DELETE','¡Listo! Resultado de búsqueda guardado.');
define('MESSAGE_JOB_ERROR','¡Oops! No se encuentra esta oportunidad laboral.');
define('MESSAGE_ERROR_SAVED_SERCH_NOT_EXIST','¡Oops! Esta búsqueda guardada no existe.');
define('INFO_TEXT_YOU_HAVE','Tienes');
define('INFO_TEXT_SAVED_SEARCH','resultados de búsqueda guardados.');
define('INFO_TEXT_NO_SAVE_RESULT','No se encontraron resultados para guardar.');
define('INFO_TEXT_CREATE_NEW_JOB_ALERT','Crear nueva alerta de oportunidad laboral');
define('INFO_TEXT_GET_DAILY_JOB_ALERTS','Recibe alertas de oportunidadesd laborales diarias por correo electrónico');
define('INFO_TEXT_SAVE_SEARCH','Guardar búsqueda:');
define('INFO_TEXT_JOB_SEARCH_CRITERIA','Los criterios de búsqueda de oportunidad laboral se pueden guardar, de modo que no tengas que seleccionar repetidamente los criterios para ejecutar la misma búsqueda.');
define('INFO_TEXT_JOB_ALERT','Alerta de oportunidad laboral:');
define('INFO_TEXT_WILL_SEND_EMAIL_NOTIFICATION','¡Te enviaremos por correo electrónico cuando haya nuevas oportunidades laborales que coincidan con tus intereses!');

?>