<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #******
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2017  #**********
**********************************************************/


if(isset($_GET['Skill']))
define('HEADING_TITLE','%s  Oportunidades laborales');
else
define('HEADING_TITLE','Búsqueda de oportunidades laborales por habilidades');
define('INFO_TEXT_JOB_CATEGORY','Categoría de trabajo :');


define('INFO_TEXT_LOCATION','Ubicación');
define('INFO_TEXT_EXPERIENCE','Experiencia');
define('INFO_TEXT_JOB_POSTED','	Muéstrame trabajos publicados en : ');
define('INFO_TEXT_DEFAULT_JOB_POST_DAY','Todas');


define('INFO_TEXT_COMPANY_NAME','Empresa ');
define('INFO_TEXT_LOCATION_NAME','Ubicación');
define('INFO_TEXT_POSTED_ON','Publicado en :');
define('INFO_TEXT_SALARY','Salario');
define('INFO_TEXT_SALARY_DOT',':');
define('INFO_TEXT_APPLY_BEFORE','Aplicar antes :');
define('INFO_TEXT_JOB_SKILL','Habilidades de trabajo');

define('INFO_TEXT_APPLY_NOW','¡Aplica ya! ');
define('INFO_TEXT_APPLY_NOW1','Postula a varios trabajos seleccionando los trabajos de tu elección.');

define('MESSAGE_ERROR_SAVED_SERCH_NOT_EXIST','¡Oops! Esta búsqueda no se encuentra.');
define('MESSAGE_ERROR_SAVED_SERCH_ALREADY_EXIST','¡Oops! Este nombre de búsqueda guardado ya existe.');
 
define('IMAGE_SEARCH','Buscar');
define('IMAGE_SAVE','Guardar búsqueda');
define('IMAGE_CANCEL','Cancelar');
define('IMAGE_BACK','atrás');
define('IMAGE_APPLY','¡Quiero aplicar!');
define('INFO_TEXT_CLICK_HERE_TOSEE_DETAILS','Haz clic aquí para ver detalles');
define('INFO_TEXT_HAS_MATCHED','haz coincidido');
define('INFO_TEXT_TO_YOUR_SEARCH_CRITERIA','según tus criterios de búsqueda.');
define('INFO_TEXT_JOB','Oportunidad laboral');
define('INFO_TEXT_JOBS','Oportunidades laborales');
define('INFO_TEXT_HAS_NOT_MATCHED','no haz hecho coincidir ningún trabajo con tus criterios de búsqueda.');
define('INFO_TEXT_ALL_JOB_CATEGORY','Todas las categorías de trabajo ...');
define('INFO_TEXT_ALL_COUNTRIES','Todos los países');
define('INFO_TEXT_DESCRIPTION','Descripción del trabajo :');
define('INFO_TEXT_EMAIL_THIS_JOB','Enviar este trabajo por correo electrónico');
define('MORE_DETAILS','Más detalles');
define('INFO_TEXT_APPLY_TO_THIS_JOB','Aplica a esta oportunidad laboral');
?>