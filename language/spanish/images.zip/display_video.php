<?php
define('PROFILE_NOT_EXIST_MESSAGE1','¡Oops! No se encuentra el perfil.');
define('VIDEO_NOT_EXIST_MESSAGE','¡Oops! No se encuentra el video.');
?>