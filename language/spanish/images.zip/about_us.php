<?
define('HEADING_TITLE','Quiénes somos');
?>