<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', 'Mis agentes de búsqueda de hojas de vida');
//////////////////////////
define('TABLE_HEADING_RUN', 'Correr');
define('TABLE_HEADING_EDIT','Editar');
define('TABLE_HEADING_DELETE','Borrar');
define('TABLE_HEADING_INSERT_DATE', 'Insertado');
define('TABLE_HEADING_UPDATE_DATE', 'Actualizado');
define('TABLE_HEADING_TITLE_NAME', 'Nombre del título');
define('MESSAGE_SUCCESS_DELETE','¡Listo! Reclutador de búsqueda eliminado.');
define('MESSAGE_ERROR_RESUME_SEARCH_AGENT_NOT_EXIST','¡Oops! Este agente de búsqueda de hojas de vida no se encuentra.');
define('INFO_TEXT_YOU_HAVE','You have');
define('INFO_TEXT_RESUME_SEARCH_AGENTS','reanudar la búsqueda de agentes.');
define('INFO_TEXT_NO_RESUME_SEARCH_AGENTS','No se encontraron agentes de búsqueda de currículum.');
define('INFO_TEXT_CREATE_NEW_RESUME_ALERT','Crear nueva alerta de hoja de vida');
define('INFO_TEXT_GET_DAILY_RESUME','Obtener una hoja de vida diaria por correo electrónico');

define('INFO_TEXT_RUN','Correr');
define('INFO_TEXT_EDIT','Editar');
define('INFO_TEXT_DELETE','Borrar');
?>