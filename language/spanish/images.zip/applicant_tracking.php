<?
define('HEADING_TITLE','Applicant Tracking');
define('INFO_TEXT_APPLICATION','Application ID');
define('ERROR_APPLICATION_NOT_EXIST','Sorry this application doesnot exist.');
define('IMAGE_SEARCH','Search Applicant');
define('INFO_TEXT_SEARCH_BY_ID','Search by Application ID :');
define('INFO_TEXT_ADVANCE_SEARCH','Advance Search :');
define('INFO_TEXT_FIRST_NAME','First Name :');
define('INFO_TEXT_LAST_NAME','Last Name :');
define('INFO_TEXT_EMAIL_ADDRESS','E-Mail Address:');
define('TABLE_HEADING_APPLICATION_NO','Application No');
define('TABLE_HEADING_NAME','Name');
define('TABLE_HEADING_EMAIL_ADDRESS','E-Mail Address');
define('TABLE_HEADING_JOB_TITLE','Job Title');
define('TABLE_HEADING_INSERTED','Inserted');
define('INFO_TEXT_APPLICATIONS','Applications');
define('INFO_TEXT_HAS_MATCHED','has matched');
define('INFO_TEXT_TO_YOUR_SEARCH','to your search criteria.');
define('INFO_TEXT_HAS_NOT_MATCHED','has not matched any applicant to your search criteria.');
define('HEADING_SEARCH','Search Applicant');
define('INFO_TEXT_UNREGISTERED_RESUMES','List of Direct Applicants');

define('TABLE_HEADING_APPL_PHOTO','Pic');
define('TABLE_HEADING_APPL_NAME','Name');
define('TABLE_HEADING_APPL_EMAIL','Email Address');
define('TABLE_HEADING_APPL_JOB_TITLE','Job Title');
define('TABLE_HEADING_APPL_STATUS','Status');
define('TABLE_HEADING_DATE_OF_APPLICATION','Date of Application');
define('TABLE_HEADING_APPL_ACTION','Action');
define('TABLE_HEADING_APPL_EDIT_STATUS','Status');

define('IMAGE_NEW','New');
define('IMAGE_PROCESS','Process');
define('IMAGE_COMPLITE_WAIT','Completed(Waiting)');
define('IMAGE_COMPLITE_REJECT','Completed(Reject)');
define('IMAGE_COMPLITE_SELECT','Completed(Select)');


?>