<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Plan de suscripción - Tarjeta de tarifas');
define('TABLE_HEADING_PLAN_TYPE_NAME','Membresia');
define('TABLE_HEADING_PLAN_TYPE_TIME_PERIOD','Periodo de tiempo');
define('TABLE_HEADING_PLAN_TYPE_FEE','Tarifa ');
define('TABLE_HEADING_PLAN_TYPE_NO_OF_JOBS','Opotunidades laborales');
define('TABLE_HEADING_PLAN_TYPE_NO_OF_CVS','Hojas de vida\'s');
define('TABLE_HEADING_PLAN_TYPE_NO_OF_SMS','Mensajes');
define('TABLE_HEADING_PLAN_TYPE_BUY','Adquirir');
?>