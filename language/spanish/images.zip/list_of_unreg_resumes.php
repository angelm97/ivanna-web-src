<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', 'Lista de candidatos');
define('TABLE_HEADING_JOB_TITLE','Título profesional');

define('TABLE_HEADING_APPLICANTNL_NAME','Nombre');
define('TABLE_HEADING_APPLICANTNL_EMAIL_ADDRESS','Dirección de correo electrónico');
define('TABLE_HEADING_INSERTED','Insertado');
define('TABLE_HEADING_RESUME_DELETE','Borrar');
define('TABLE_HEADING_RESUME_VIEW','Vista');

define('MESSAGE_SUCCESS_DELETED', '¡Listo! Eliminado correctamente.');
define('INFO_TEXT_RESUME','Reanudar');
define('INFO_TEXT_RESUMES','Reanudar');
define('INFO_TEXT_HAS_SAVED','Ha sido guardado');
define('INFO_TEXT_TO_YOUR_SEARCH_CRITERIA','a tus criterios de búsqueda.');
define('INFO_TEXT_HAS_NOT_SAVED','No has guardado ninguna hoja de vida según tus criterios de búsqueda.');
define('INFO_TEXT_ALL','Todas');
define('INFO_TEXT_LIST_OF_APPLICATIONS','Lista de candidatos registrados');

?>