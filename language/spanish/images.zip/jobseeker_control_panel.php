<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/
define('HEADING_TITLE','Panel de búsqueda de oportunidad laboral');

define('INFO_TEXT_BRIEFPROFILE','Perfil breve');
define('INFO_TEXT_EMAIL_ADDRESS','Dirección de correo electrónico :');
define('INFO_TEXT_ADDRESS','Ubicación actual :');
define('INFO_TEXT_PHONE','Número de telefono :');
define('INFO_TEXT_MOBILE','Móvil:');
define('INFO_TEXT_RESUME_VIEWED','No. de veces que se reanudaron las visitas :');
define('INFO_TEXT_ADD_PHOTO','Añadir foto');
define('INFO_TEXT_EDIT_PHOTO','Editar foto');

define('INFO_TEXT_RESUME_MANAGER','Resumen');
define('INFO_TEXT_ADD_RESUMES','Agregar hojas de vida');
define('INFO_TEXT_LIST_OF_RESUMES','Mis hojas de vida');

define('INFO_TEXT_JOBS','Oportunidades laborales');
define('INFO_TEXT_LIST_OF_SAVED_JOBS','Mis trabajos guardados');
define('INFO_TEXT_LIST_OF_APPLICATIONS','Mis aplicaciónes');

define('INFO_TEXT_MY_ACCOUNT','Mi cuenta');
define('INFO_TEXT_EDIT_PERSONAL_DETAILS','Editar datos personales');

define('INFO_TEXT_HEADER_JOB_SEARCH','Mi búsqueda de oportunidad laboral');
define('INFO_TEXT_JOB_SEARCH','Buscar oportunidades laborales');
define('INFO_TEXT_SERCH_BY_LOCATION','Buscar oportunidades laborales por ubicación');
define('INFO_TEXT_SERCH_BY_CATEGORY','Buscar oportunidades laborales por industria');
define('INFO_TEXT_COMPANY_PROFILE','Buscar oportunidades laborales por empresas');

define('INFO_TEXT_LIST_OF_COVER_LETTERS','Mis cartas de presentación');
define('INFO_TEXT_LIST_OF_SAVED_SEARCHES','Mis búsquedas guardadas');
define('INFO_TEXT_JOB_ALERT_AGENT','Alerta de oportunidades laborales');
define('INFO_TEXT_CHANGE_PASSWORD','Cambiar la contraseña');

define('INFO_TEXT_AVAILABILITY','Establecer estado como disponible ahora');
define('STATUS_NOT_AVAILABLE', 'Establecer estado como No disponible');
define('STATUS_NOT_AVAILABLITY', 'No disponible');
define('STATUS_AVAILABLE', 'Disponible');
define('STATUS_AVAILABLITY', 'Establecer estado como disponible');
define('MESSAGE_SUCCESS_UPDATED_AVAILABLE', '¡Listo! Se estableció correctamente el estado de su oportunidad laboral como <b>Disponible ahora</b>.');
define('MESSAGE_SUCCESS_UPDATED_NOT_AVAILABLE', 'Éxito: estado de reanudación establecido en <b>NO DISPONIBLE</b>. Recuerda que ahora tus hojas de vida están fuera del motor de búsqueda.');
define('INFO_TEXT_NEWSLETTER','Boletines');
define('INFO_TEXT_MY_MAILS','Respuesta de los empleadores');
define('INFO_TEXT_CONTACT_LIST','Lista de contactos');
define('INFO_TEXT_VIDEO_RESUME','Reanudar video');
define('INFO_TEXT_LOGOUT','Cerrar sesión');
define('INFO_TEXT_JOIN_FORUM','Unirse al foro');
define('INFO_TEXT_RESUME_STATISTICS','Reanudar estadísticas');
define('INFO_TEXT_JOBSEEKER_ORDER_HISTORY','Historial de pedidos');
define('INFO_TEXT_JOBS_BY_KEYWORD','Buscar oportunidades laborales por palabra clave');
?>