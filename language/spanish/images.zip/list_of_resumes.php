<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', 'Lista de hojas de vida guardadas');


define('TABLE_HEADING_JOBSEEKER_NAME','Nombre');
define('TABLE_HEADING_JOBSEEKER_EMAIL_ADDRESS','Dirección de correo electrónico');
define('TABLE_HEADING_INSERTED','Insertado');
define('TABLE_HEADING_RESUME_RATING','Clasificación');
define('TABLE_HEADING_RESUME_DELETE','Borrar');
define('TABLE_HEADING_RESUME_VIEW','Vista');

define('MESSAGE_SUCCESS_DELETED', '¡Listo! Hoja de vida eliminada.');
define('INFO_TEXT_RESUME','Reanudar');
define('INFO_TEXT_RESUMES','Reanuda');
define('INFO_TEXT_HAS_SAVED','ha salvado');
define('INFO_TEXT_TO_YOUR_SEARCH_CRITERIA','a sus criterios de búsqueda.');
define('INFO_TEXT_HAS_NOT_SAVED','No has guardado ninguna hoja de vida con tus criterios de búsqueda.');
define('INFO_TEXT_ALL','Todas');
define('INFO_TEXT_RATING','Clasificación :');

?>