<?
define('HEADING_TITLE','Artículo');
define('ERROR_CATEGORY_NOT_EXIST','¡Oops! Lo sentimos, no existe ningún boletín.');
define('TEXT_DISPLAY_NUMBER_OF_ARTICLES', 'Visualización <b>%d</b> para <b>%d</b> (of <b>%d</b> Artículos)');
define('INFO_TEXT_NEWSLETTER','Inicio');
define('INFO_TEXT_CATEGORY','Categorías');
define('INFO_TEXT_EMAIL','Enviar a amigos');
define('INFO_TEXT_PRINT','Imprime este artículo');
define('INFO_TEXT_MORE','Más');
define('INFO_TEXT_SORRY_NO_ARTICLE','Lo sentimos, no existe ningún artículo.');
define('INFO_TEXT_BY','Por');
define('INFO_TEXT_ARTICLE_BY_CATEGORY','Artículos por categoría');
define('INFO_TEXT_LATEST_ARTICLE','Últimos artículos');
define('INFO_TEXT_PRINT_ARTICLE','Imprimir artículo');
define('INFO_TEXT_SORRY_NO_FILE_EXIST','Lo sentimos, no existe ningún archivo.');
?>