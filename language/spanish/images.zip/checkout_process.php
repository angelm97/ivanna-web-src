<?
define('EMAIL_TEXT_SUBJECT', 'Orden en proceso');
define('EMAIL_TEXT_ORDER_NUMBER', 'Número de orden:');
define('EMAIL_TEXT_INVOICE_URL', 'Factura detallada:');
define('EMAIL_TEXT_DATE_ORDERED', 'Fecha del pedido:');
define('EMAIL_TEXT_PRODUCTS', 'Productos');
define('EMAIL_TEXT_SUBTOTAL', 'Total parcial:');
define('EMAIL_TEXT_TAX', 'Impuesto:        ');
define('EMAIL_TEXT_SHIPPING', 'Transporte: ');
define('EMAIL_TEXT_TOTAL', 'Total:    ');
define('EMAIL_TEXT_DELIVERY_ADDRESS', 'Dirección de entrega');
define('EMAIL_TEXT_BILLING_ADDRESS', 'Dirección de envío');
define('EMAIL_TEXT_PAYMENT_METHOD', 'Método de pago');
define('TEXT_SUCCESS', '¡Gracias! Hemos recibido tu orden.');
define('TEXT_DEMO_SUCCESS', '¡Listo, ya puedes drisfrutar de la plataforma más Wao para publicar oportunidades laborales y encontrar el talento ideal!');
define('TEXT_PAYPAL_SUCCESS', '¡Listo, ya puedes drisfrutar de la plataforma más Wao para publicar oportunidades laborales y encontrar el talento ideal!');

define('EMAIL_SEPARATOR', '------------------------------------------------------');
define('TEXT_EMAIL_VIA', 'vía');
?>