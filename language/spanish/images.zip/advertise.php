<?
define('HEADING_TITLE','Publica con nosotros');
define('INFO_TEXT_CONTENT','Bajo construcción');
?>