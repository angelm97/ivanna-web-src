<?
  define('MODULE_ORDER_TOTAL_TOTAL_TITLE', 'Total');
  define('MODULE_ORDER_TOTAL_TOTAL_DESCRIPTION', 'Order Total');
?>