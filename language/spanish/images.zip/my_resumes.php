<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Mis hojas de vida');
define('TABLE_HEADING_RESUME_NAME', 'Nombre de hoja de vida');
define('TABLE_HEADING_INSERTED', 'Insertado');
define('TABLE_HEADING_UPDATED', 'Actualizado');
define('TABLE_HEADINGVIEWED', 'Visto');
define('TABLE_HEADING_EDIT', 'Editar');
define('TABLE_HEADING_DELETE', 'Borrar');
define('TABLE_HEADING_VIEW', 'Vista');
define('TABLE_HEADING_DUPLICATE', 'duplicada');

define('INFO_TEXT_EDIT', 'Editar');
define('INFO_TEXT_DELETE', 'Borrar');
define('INFO_TEXT_VIEW', 'Vista');
define('INFO_TEXT_DUPLICATE', 'duplicada');

define('MESSAGE_SUCCESS_UPDATED', '¡Listo! Hoja de vida actualizada.');
define('MESSAGE_SUCCESS_DELETED', '¡Listo! Hoja de vida eliminada.');
define('MESSAGE_SUCCESS_DUPLICATED', '¡Listo! Hoja de vida duplicada.');
define('INFO_TEXT_MAX_RESUME', 'Nota: puedes crear hasta <b>% d </b> hojas de vida.');
define('TABLE_HEADING_SEARCHABLE', 'Buscable?');

define('STATUS_RESUME_NOT_SEARCH', '¿No se puede buscar?');
define('STATUS_RESUME_NOT_SEARCHABLE', '¿No se puede buscar??');

define('STATUS_RESUME_SEARCH', 'Buscable');
define('STATUS_RESUME_SEARCHABLE', 'Buscable?');

define('TABLE_HEADING_AVAILABILITY', 'Disponible?');
define('STATUS_NOT_AVAILABLE', '¿No disponible?');
define('STATUS_NOT_AVAILABLITY', '¿No disponible??');

define('STATUS_AVAILABLE', 'Disponible');
define('STATUS_AVAILABLITY', 'Disponible?');
define('NOT_ACTIVATION_ERROR', 'Para que se pueda buscar tu hoja de vida, ve a la página de registro (Editar perfil) y selecciona "¿Se puede buscar mi hoja de vida? Sí"');
define('INFO_TEXT_ADD_NEW_RESUME','Agregar nueva hoja de vida');
?>