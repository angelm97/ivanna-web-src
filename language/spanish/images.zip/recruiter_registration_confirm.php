<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', '¡Tu cuenta ha sido creada! Ya puedes ingresar a WaoJobs y encontrar el trabajo de tus sueños.');
define('TEXT_ACCOUNT_CREATED', 'Hola Talents name, %s, ¡Felicidades!

Estamos muy emocionados, te has registrado con éxito en Waojobs.com.

¡Ahora puedes empezar a disfrutar de todos los beneficios de nuestro portal y encontrar el trabajo de tus sueños!

Un saludo,

El equipo de WaoJobs;)
<small>
<b>ALGUNA</b></small>
Escríbenos por aquí, nuestro Equipo WaoJobs está para apoyarte
'.stripslashes(CONTACT_ADMIN).'<br><br>
Hemos enviado una confirmación a tu correo electrónico. Si no la recibes, por favor comunícate con el Equipo WaoJobs.
'.stripslashes(CONTACT_ADMIN).'.<br><br>
<b>Tu nombre de usuario :</b> %s <br><b>Tu contraseña :</b> %s <br><br>
¡Listo! Usuario y contraseña creada. Ya puedes ingresar a WaoJobs.<br><b>'.tep_db_output(SITE_TITLE).'</b>');
?>