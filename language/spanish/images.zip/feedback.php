<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Realimentación');
define('INFO_TEXT_FULL_NAME','Nombre completo : ');
define('INFO_TEXT_EMAIL_ADDRESS','Dirección de correo electrónico : ');
define('INFO_TEXT_SUBJECT','Asunto : ');
define('INFO_TEXT_MESSAGE','Mensaje : ');
define('SUCCESS_EMAIL_SENT','¡Listo! Mensaje enviado.');
define('IMAGE_SEND','Enviar');
?>