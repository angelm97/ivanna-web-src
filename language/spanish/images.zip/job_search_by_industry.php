<?
if($_POST['action']=='search')
{
 define('HEADING_TITLE','Resultados de la búsqueda');
}
else
 define('HEADING_TITLE','Buscar trabajo por industria');

define('INFO_TEXT_INDUSTRY_SECTOR','¿En qué área de interés te gustaría trabajar?: ');



define('INFO_TEXT_KEYWORD','Palabra clave : ');
define('INFO_TEXT_LOCATION','Ubicación');
define('INFO_TEXT_EXPERIENCE','Experiencia');
define('INFO_TEXT_COMPANY_NAME','Empresa ');
define('INFO_TEXT_LOCATION_NAME','Ubicación');
define('INFO_TEXT_SALARY','Salario');
define('INFO_TEXT_SALARY_DOT',':');
define('INFO_TEXT_APPLY_BEFORE','Aplicar antes :');

define('INFO_TEXT_APPLY_NOW','Aplica ya ! ');
define('INFO_TEXT_APPLY_NOW1','Postulate a varias oportunidades laborales seleccionando tus áreas de interés.');

define('IMAGE_SEARCH','Buscar');
define('IMAGE_SAVE','Guardar búsqueda');
define('IMAGE_CANCEL','Cancelar');
define('IMAGE_BACK','Atrás');
define('IMAGE_APPLY','Aplica ya');
define('INFO_TEXT_CLICK_HERE_TOSEE_DETAILS','Haz clic aquí para ver detalles');
define('INFO_TEXT_HAS_MATCHED','Ha coincidido');
define('INFO_TEXT_TO_YOUR_SEARCH_CRITERIA','según tus criterios de búsqueda.');
define('INFO_TEXT_JOB','Oportunidad laboral');
define('INFO_TEXT_JOBS','Oportunidades laborales');
define('INFO_TEXT_HAS_NOT_MATCHED','no has hecho coincidir ninguna oportunidad laboral con tus criterios de búsqueda.');
define('INFO_TEXT_ALL_JOB_CATEGORY','Todas las categorías de empleo ...');
define('INFO_TEXT_ALL_COUNTRIES','Todos los países');

define('INFO_TEXT_EMAIL_THIS_JOB','Enviar este trabajo por correo electrónico');
define('INFO_TEXT_APPLY_TO_THIS_JOB','Aplica a esta oportunidad laboral');

?>