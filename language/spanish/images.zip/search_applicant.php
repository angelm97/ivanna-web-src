<?
define('HEADING_TITLE','Lista de candidatos');
define('INFO_TEXT_APPLICATION','ID de aplicación');
define('ERROR_APPLICATION_NOT_EXIST','¡Oops! Esta aplicación no existe.');
define('IMAGE_SEARCH','Búsqueda de talento');
define('INFO_TEXT_SEARCH_BY_ID','Buscar por ID de aplicación:');
define('INFO_TEXT_ADVANCE_SEARCH','Búsqueda avanzada:');
define('INFO_TEXT_FIRST_NAME','Primer nombre:');
define('INFO_TEXT_LAST_NAME','Apellido:');
define('INFO_TEXT_EMAIL_ADDRESS','Dirección de correo electrónico:');
define('TABLE_HEADING_APPLICATION_NO','Solicitud No');
define('TABLE_HEADING_NAME','Nombre');
define('TABLE_HEADING_EMAIL_ADDRESS','Dirección de correo electrónico');
define('TABLE_HEADING_JOB_TITLE','Título profesional');
define('TABLE_HEADING_INSERTED','Insertado');
define('INFO_TEXT_APPLICATIONS','Aplicaciones');
define('INFO_TEXT_HAS_MATCHED','Has coincidido');
define('INFO_TEXT_TO_YOUR_SEARCH','según tus criterios de búsqueda.');
define('INFO_TEXT_HAS_NOT_MATCHED','No has hecho coincidir ningún candidato con tus criterios de búsqueda.');
define('HEADING_SEARCH','Búsqueda de talento');
define('INFO_TEXT_UNREGISTERED_RESUMES','Lista de candidatos directos');

?>