<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Plan de suscripción - Tarjeta de tarifas: Los mejores Paquetes de suscripción');

define('TABLE_HEADING_PLAN_TYPE_NAME','Paquete');
define('TABLE_HEADING_PLAN_TYPE_TIME_PERIOD','Duración');
define('TABLE_HEADING_PLAN_TYPE_FEE','Precio');
define('TABLE_HEADING_PLAN_TYPE_NO_OF_JOBS','Búsquedas de hojas de vida');
define('TABLE_HEADING_PLAN_TYPE_NO_OF_CVS','Oportunidades laborales');
define('TABLE_HEADING_PLAN_TYPE_NO_OF_SMS','SMS');
define('TABLE_HEADING_PLAN_TYPE_BUY','Comprar');
define('INFO_TEXT_FREE_SERVICE','servicio gratuito');
define('INFO_TEXT_UNLIMITED','Ilimitado');
define('INFO_TEXT_QUOT1','Publica tus oportunidades laborales y accede a la hoja de vida al instante: ¡Estos paquetes te ayudarán a encontrar el talento ideal para tu compañía!');
define('INFO_TEXT_QUOT2','Estos paquetes te ayudarán a contratar al talento ideal de inmediato. Selecciona el producto que deseas comprar:');
define('INFO_TEXT_POST_JOBS','Publicación de oportunidades laborales o vacantes');
define('INFO_TEXT_F_POST_JOBS','Publicar oportunidades destacados');
define('INFO_TEXT_SEARCH_RESUMES','Búsqueda de hojas de vida');
define('INFO_TEXT_POST_SEARCH','Publicar oportunidades laborales y hojas de vida: Los mejores paquetes');
define('INFO_TEXT_F_POST_SEARCH','Publicar trabajos destacados y hojas de vida');
define('INFO_TEXT_KEY_FEATURES','Descripción del paquete');
define('INFO_TEXT_POST_JOB_INSTANTLY','Publica tu oportunidad laboral al instante');
define('INFO_TEXT_MANAGE_MONITOR','Administra y monitorea los resultados');
define('INFO_TEXT_TRACK_APPLICATION','Realiza el proceso de selección en línea');
define('INFO_TEXT_GET_RESUMES','Obten hojas de vida por correo electrónico');
define('INFO_TEXT_SEARCH_QUALIFIED','Busca el talento ideal para tu compañía');
define('INFO_TEXT_VIEW_SAVE_ORGANISATION','Ver, guardar y organizar hojas de vida en línea');
define('INFO_TEXT_GET_ACCESS_TO_RESUME','Obtén acceso a la base de datos de hojas de vida al instante');
define('INFO_TEXT_USE_APPLICANT_TRACKING','Utiliza la herramienta de seguimiento de candidatos para preseleccionar los mejores');
define('INFO_TEXT_FOR_OTHER_OPTIONS','¿Tienes alguna duda?');
define('INFO_TEXT_CONTACT_US','El Equipo WaoJobs está para ayudarte, haz clic AQUÍ.');
define('BUY_NOW','¡Quiero este!');
?>