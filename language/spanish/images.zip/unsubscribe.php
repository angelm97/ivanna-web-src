<?
define('SORRY_NO_EMAIL_ADDRESS_EXIST','¡Oops! Tu dirección de correo electrónico no existe.');
define('EMAIL_UNSUBSCRIBE_SUCCESS','Sentimos que te vayas :( Has cancelado la suscripción de nuestro boletín exitosamente.');
define('ALL_READY_EMAIL_UNSUBSCRIBE','Ya has cancelado la suscripción de nuestro boletín.');
?>