<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Reanudar estadísticas');
define('TABLE_HEADING_RESUME_NAME', 'Nombre de la hoja de vida');
define('TABLE_HEADING_INSERTED', 'Visto en');
define('TABLE_HEADING_COMPANY_NAME', 'Nombre de empresa');
define('INFO_TEXT_STATISTICS','Estadísticas');
define('INFO_TEXT_NO_STATISTICS_AVAILABLE','Lo sentimos, estadísticas no disponibles.');
?>