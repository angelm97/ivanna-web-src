<?
define('HEADING_TITLE','Tipo de talento');
define('INFO_TEXT_CANDIDATE_TYPE','Por favor seleccione el tipo :');
define('IMAGE_NEXT','Siguiente >>');
define('FEATURED_MEMBER_ERROR','Como ya eres un miembro destacado, por el momento no puedes cambiar tu membresía hasta que caduque. Si tienes alguna inquietud, el Equipo WaoJobs está para ayudarte, escríbenos AQUÍ.');
define('INFO_TEXT_FEATURED','Presentado');
define('INFO_TEXT_REGULAR','Regular');
?>