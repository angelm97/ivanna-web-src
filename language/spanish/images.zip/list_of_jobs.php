<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


if($_GET['action']=='add_screener' || $_GET['action']=='edit_screener')
{
 define('HEADING_TITLE', 'Agregar / Editar evaluador');
}
else
{
 define('HEADING_TITLE', 'Lista de% s trabajos');
}
//////////////////////////
define('HEADING_TITLE_READV', 'Volver a anunciar esta oportunidad laboral');
define('INFO_TEXT_READVERTISE', 'Volver a anunciar desde: ');
define('INFO_TEXT_ADVERTISE_WEEKS','¿Cuántas semanas te gustaría anunciar esta oportunidad laboral :');
////////////
define('TEXT_INFO_EDIT_JOB_INTRO', 'Realiza los cambios necesarios');
define('TEXT_DELETE_INTRO', '¿Quieres eliminar esta oportunidad laboral?');
define('TEXT_SCREENER_DELETE_INTRO', '¿Quieres eliminar este filtro?');
if($_GET['j_status']=='deleted')
 define('TEXT_DELETE_WARNING', '<font color="red"><b>Ten en cuenta: </b></font> Con esta oportunidad también se eliminarán todos los datos del candidato.');
else
 define('TEXT_DELETE_WARNING', '<font color="red"><b>Ten en cuenta: </b></font>Esta oportunidad laboral no se eliminará por completo de la base de datos. Simplemente irá a <b>la categoría de eliminadas</b> Categoría.');

define('TEXT_DELETE_SCREENER_WARNING', '<font color="red"><b>Ten en cuenta: </b></font>Pantallazo se eliminará físicamente de la base de datos.');

define('TEXT_INFO_NEW_JOB_INTRO', 'No se agregó información del trabajo.');
define('TEXT_INFO_JOB_INSERTED', 'Oportunidad laboral agregada el:');
define('TEXT_INFO_JOB_UPDADED', 'Oportunidad laboral modificada en:');
define('TEXT_INFO_FULLNAME', 'Nombre:');
define('TEXT_INFO_EMAIL', 'Dirección de correo electrónico:');
define('TEXT_INFO_JOB_STARTS', 'El puesto comienza en:');
define('TEXT_INFO_JOB_ENDS', 'El puesto termina el:');
define('TEXT_INFO_JOB_JOB_STATUS', 'Estado de la oportunidad laboral:');
define('TEXT_INFO_JOB_NO_OF_JOBS', 'Número máximo de oportunidades laborales:');
define('TEXT_INFO_JOB_CV_STATUS', 'Estado de hoja de vida:');
define('TEXT_INFO_JOB_NO_OF_CVS', 'Número de días máximo para buscar hoja de vida:');



define('TABLE_HEADING_REFERENCE', 'Referencia');
define('TABLE_HEADING_TITLE', 'Título');
define('TABLE_HEADING_INSERTED', 'Insertado');
define('TABLE_HEADING_EXPIRED', 'Caducado');
define('TABLE_HEADING_STATUS', 'Estado');
define('TABLE_HEADING_VIEWED', 'Visto');
define('TABLE_HEADING_CLICKED', 'Hizo clic');
define('TABLE_HEADING_APPLICATIONS', 'Solicitud');
define('TABLE_HEADING_ACTION', 'Acción');

define('STATUS_JOB_INACTIVE', 'Inactivo');
define('STATUS_JOB_INACTIVATE', 'inactivar?');

define('STATUS_JOB_ACTIVE', 'Activo');
define('STATUS_JOB_ACTIVATE', '¿Activar?');


define('MESSAGE_SUCCESS_DELETED','Éxito: trabajo eliminado correctamente.');
define('MESSAGE_SUCCESS_UPDATED','Éxito: el trabajo se actualizó correctamente.');

define('MESSAGE_UNSUCCESS_SCREENER_DELETED','error: debido a algún problema, el examinador no se elimina.');
define('MESSAGE_SUCCESS_SCREENER_DELETED','¡Listo! Evaluador eliminado.');
define('MESSAGE_SUCCESS_JOB_UNDELETED','Success: Job is successfully Re-added.');

define('MESSAGE_SUCCESS_SCREENER_INSERTED','¡Listo! Evaluador ingresado.');
define('MESSAGE_SUCCESS_SCREENER_UPDATED','¡Listo! Evaluador actualizado.');
define('MESSAGE_JOB_SUCCESS_READVERTISED','¡Listo! La oportunidad laboral se volvió a publicar.');
define('MESSAGE_JOB_UNSUCCESS_READVERTISED','¡Oops¡No pudimos publicar nuevamente la oportunidad laboral.');
define('MESSAGE_JOB_UNSUCCESS_READVERTISED1','¡Oops! Te quedan % s puntos de trabajo, reduce las semanas de la oportunidad laboral');
define('MESSAGE_JOB_UNSUCCESS_READVERTISED2','¡Oops! Te quedan % s punto de trabajo, comunícate con nosotros AQUÍ, estamos para ayudarte.');

define('MESSAGE_JOB_ERROR','¡Oops¡No pudimos publicar nuevamente la oportunidad laboral. El Equipo WaoJobs está para ayudarte, escríbenos AQUÍ.');

define('MESSAGE_SUCCESS_STATUS_UPDATED','¡Lsito! Oportunidad laboral actualizada.');


define('INFO_TEXT_RESUME_WEIGHT','Reanudar peso');

define('IMAGE_NEW','Agregar nueva oportunidad laboral');
define('IMAGE_BACK','Atrás');
define('IMAGE_NEXT','Próximo');
define('IMAGE_CANCEL','Cancelar');
define('IMAGE_INSERT','Insertar');
define('IMAGE_EDIT','Editar oportunidad laboral');
define('IMAGE_UPDATE','Actualizar');
define('IMAGE_DELETE','Eliminar oportunidad laboral');
define('IMAGE_CONFIRM','Confirmar eliminación');
define('IMAGE_PREVIEW','Vista previa de la oportunidad laboral');
define('IMAGE_UPDATE','Actualizar');
define('IMAGE_EDIT_JOB','Editar oportunidad laboral');
define('IMAGE_DELETE_JOB','Eliminar oportunidad laboral');
define('IMAGE_UNDELETE_JOB','Un-delete job');
define('IMAGE_READVERTISE','Volver a anunciar oportunidad laboral');
define('IMAGE_APPLICATIONS','Ver aplicaciones');
define('IMAGE_ADD_SCREENER','Agregar evaluador');
define('IMAGE_EDIT_SCREENER','Editar filtro');
define('IMAGE_DELETE_SCREENER','Eliminar filtro');
define('IMAGE_REPORT','Ver los informes');
define('IMAGE_SELECTED_APPLICATIONS','Candidatos seleccionados');

define('ERROR_QUESTION','Completa la pregunta no. <b>%s</b> primero.');
define('IMAGE_VIEW_JOB','Ver oportunidad laboral');
define('INFO_TEXT_QUESTION','Pregunta-');
define('INFO_TEXT_ACTIVE_JOBS','Oportunidades laborales activas');
define('INFO_TEXT_EXPIRED_JOBS','Oportunidades laborales caducadas');
define('INFO_TEXT_DELETED_JOBS','Oportunidades laborales eliminadas');
define('INFO_TEXT_OTHER_JOBS','Otras oportunidades laborales ');
define('INFO_TEXT_SPECIFY_VACANCY_PERIOD','Especifique el período de la oportunidades laboral');
define('INFO_TEXT_ONE_WEEK','Una semana');
define('INFO_TEXT_TWO_WEEKS','Dos semanas');
define('INFO_TEXT_THREE_WEEKS','Tres semanas');
define('INFO_TEXT_ONE_MONTH','Un mes');
define('INFO_TEXT_YES','Si');
define('INFO_TEXT_NO','No');
define('INFO_TEXT_SCREENER_QUESTION','¡Esta sección la hicimos pensando en tí! Aquí puedes agregar hasta 10 preguntas de selección para que los candidatos que apliquen, las respondan. Estas preguntas te ayudarán a filtrar los candidatos ideales ;).<br>
             <em>Esta es una característica opcional, no es necesaria para publicar en este cargo. </em>');
define('INFO_TEXT_ADD_UPTO_FIVE','Aquí puedes agregar hasta 5 preguntas abiertas.<br>
¡Esta sección la hicimos pensando en tí! Aquí puedes agregar hasta 5 preguntas abiertas, las cuales te ayudarán a ver cómo responden los candidatos en sus propias palabras. Ejemplos de preguntas abiertas: ¿Cuál sería tu trabajo ideal? ¿Qué nos diría tu anterior jefe sobre tí? ¿Que es lo que más admiras de ti y lo que quisieras mejorar? &quot; ');
?>