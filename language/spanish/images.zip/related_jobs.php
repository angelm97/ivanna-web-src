<?
/**********************************************************
**********# Name      : Shambhu Prasad Patnaik  #**********
**********# Company   : Aynsoft                 #**********
**********# Copyright (c) www.aynsoft.com 2013  #**********
**********************************************************/

define('HEADING_TITLE','Oportunidades laboales relacionadas');
define('INFO_TEXT_EMAIL_THIS_JOB','Recomendar a un amigo');
define('INFO_TEXT_APPLY_TO_THIS_JOB','¡Quiero aplicar!');
?>