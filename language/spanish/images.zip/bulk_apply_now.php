<?
define('HEADING_TITLE','¡Quiero aplicar!');
define('HEADING_SECTION','¡Oops! Te falta algo por completar, revisa y envía la solicitud nuevamente.');

define('INFO_TEXT_TO','Para : ');
define('INFO_TEXT_FROM','De : ');
define('INFO_TEXT_EMAIL','Correo electrónico : ');
define('INFO_TEXT_SUBJECT','Asunto : ');
define('INFO_TEXT_COVER_LETTER','Tu carta de presentación : ');
define('INFO_TEXT_RESUMES','Tu resumen : ');
define('INFO_TEXT_VIEW_CV_LINK','Para ver mi hoja de vida, haz clic en el siguiente enlace.%s');

define('ERROR_RESUME_NOT_EXIST','¡Oops! Primero debes agregar tu hoja de vida.');
define('ERROR_JOB_NOT_EXIST','¡Oops! Esta oportunidad laboral ya no se encuentra.');
define('INFO_TEXT_CV','Adjunta tu hoja de vida: ');
define('INFO_TEXT_DEFALUT_COVER_LETTER',' Me encantaría participar en el proceso de selección para la oportunidad laboral que postularon en Waojobs.com. Pueden ver mi hoja de vida.');
define('INFO_TEXT_DEFALUT_COVER_LETTER1',' [ La carta de presentación anterior es una guía. Puedes modificarla o crear una nueva en panel de control para que te salga automáticamente en todas las aplicaciones. ] %s');

define('MESSAGE_SUCCESS_APPLED','¡Cada vez más cerca al trabajo de tus sueños!');
define('ERROR','Completa primero tu información personal.');
////
define('IMAGE_CONFIRM','¡Quiero aplicar!');
define('INFO_TEXT_ANSWER','Respuesta');
define('INFO_TEXT_THE_CANDIDATE_RESPOND','El candidato ha respondido positivamente a');
define('INFO_TEXT_QUALIFICATION_QUESTION','Preguntas de calificación.');
define('INFO_TEXT_VIEW_RESUME','Ver hoja de vida');
define('INFO_TEXT_JOBSITE_APPLICATION','Panel de seguimiento de candidatos -');
define('INFO_TEXT_SCREENER','Pantallazo');
define('INFO_TEXT_QUESTION','Pregunta');
define('INFO_TEXT_ANSWER','Respuesta-');
define('INFO_TEXT_NOT_ADDED_YET','Aún no agregado.');
define('INFO_TEXT_ADD_NEW_RESUME','¿Agregar nueva hoja de vida?');
define('INFO_TEXT_ADD_NEW_COVER_LETTER','¿Agregar nueva carta de presentación?');
define('INFO_TEXT_JOB_TITLE','Título profesional');

?>