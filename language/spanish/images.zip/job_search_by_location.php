<?
if($_POST['action']=='search')
{
 define('HEADING_TITLE','Resultados de la búsqueda');
}
else
 define('HEADING_TITLE','Buscar trabajo por ubicación');

define('INFO_TEXT_COUNTRY','What country would you like to work in? : ');
define('INFO_TEXT_STATE','¿En qué provincia te gustaría trabajar? : ');

define('INFO_TEXT_KEYWORD','Palabra clave : ');
define('INFO_TEXT_LOCATION','Ubicación');
define('INFO_TEXT_EXPERIENCE','Experiencia');
define('INFO_TEXT_COMPANY_NAME','Empresa ');
define('INFO_TEXT_LOCATION_NAME','Ubicación');
define('INFO_TEXT_SALARY','Salario');
define('INFO_TEXT_SALARY_DOT',':');
define('INFO_TEXT_APPLY_BEFORE','Aplicar antes :');
define('INFO_TEXT_JOB_SKILL','Job Skills');

define('INFO_TEXT_APPLY_NOW','Aplica ya! ');
define('INFO_TEXT_APPLY_NOW1','Postulate a varias oportunidades laborales seleccionando tus áreas de interés.');
define('INFO_TEXT_JOB_TYPE','Tipo de empleo :');

define('IMAGE_SEARCH','Buscar');
define('IMAGE_SAVE','Guardar búsqueda');
define('IMAGE_CANCEL','Cancelar');
define('IMAGE_BACK','Atrás');
define('IMAGE_APPLY','Aplica ya');
define('INFO_TEXT_CLICK_HERE_TOSEE_DETAILS','Haz clic aquí para ver detalles');
define('INFO_TEXT_HAS_MATCHED','Ha coincidido');
define('INFO_TEXT_TO_YOUR_SEARCH_CRITERIA','según tus criterios de búsqueda.');
define('INFO_TEXT_JOB','Oportunidad laboral');
define('INFO_TEXT_JOBS','Oportunidades laborales');
define('INFO_TEXT_HAS_NOT_MATCHED','no has coincidido en ninguna oportunidad laboral con tus criterios de búsqueda.');
define('INFO_TEXT_ALL_JOB_CATEGORY','Todas las categorías de trabajo ...');
define('INFO_TEXT_ALL_COUNTRIES','All countries');
define('INFO_TEXT_DESCRIPTION','Descripción del trabajo:');
define('INFO_TEXT_EMAIL_THIS_JOB','Enviar esta oportunidad laboral por correo electrónico');
define('MORE_DETAILS','Más detalles');
define('INFO_TEXT_APPLY_TO_THIS_JOB','Aplica a esta oportunidad laboral');

?>