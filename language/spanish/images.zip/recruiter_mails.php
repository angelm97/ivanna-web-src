<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik#**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/
define('HEADING_TITLE', 'Respuesta del administrador');
define('HEADING_TITLE1','Responder al administrador');
define('INFO_TEXT_SUBJECT', 'Sujeto:');
define('INFO_MAIL_ATTACHMENT', 'Adjunto archivo :');
define('INFO_TEXT_DESCRIPTION', 'Descripción:');
define('INFO_TEXT_MESSAGE', 'Mensaje:');

define('TABLE_HEADING_JOB_TITLE', 'Título profesional');

define('TABLE_HEADING_MAIL_SENDER', 'Remitente');
define('TABLE_HEADING_MAIL_SUBJECT', 'Sujeto');
define('TABLE_HEADING_MAIL_INSERTED', 'Fecha');

define('ERROR_MAIL_NOT_EXIST','¡Oops! El correo no existe. Si el problema persiste, comuníquese con el Equipo WaoJobs AQUÍ.');
define('MESSAGE_SUCCESS_MARKED','¡Listo! Correo marcado');
define('MESSAGE_SUCCESS_DELETED','¡Listo! Correo eliminado');
define('MESSAGE_SUCCESS_RESTORE','¡Listo! Correo restaurado en tu bandeja de entrada');
define('MESSAGE_SUCCESS_UNMARKED','¡Listo! Correo eliminado de la marca');
define('HEADING_TO_EMAIL','Para:');
define('INFO_TEXT_FROM_EMAIL','De:');
define('IMAGE_BACK', 'Atrás');
define('IMAGE_ATTACHMENT','Archivo adjunto');
define('MESSAGE_SUCCESS_SENT','Respuesta enviada con éxito');
define('INFO_TEXT_VIEW_IN_TRASH','Ver en la papelera');
define('INFO_TEXT_VIEW_IN_INBOX','Ver en la bandeja de entrada');
define('INFO_TEXT_VIEW_ALL','Todos');
define('INFO_TEXT_VIEW_MARKED','Marcado');
define('INFO_TEXT_VIEW_IN','Ver en');
define('INFO_TEXT_UNREAD','No leído');
define('INFO_TEXT_MAIL','Correo');
define('INFO_TEXT_MAILS','Correos');
define('INFO_TEXT_HAS_FOUND','Haz encontrado');
define('INFO_TEXT_CHECK_ALL','Comprobar todo');
define('INFO_TEXT_UNCHECK_ALL','Desmarcar todo');
define('INFO_TEXT_WITH_SELECTED','con seleccionado');
define('INFO_TEXT_WITH_SELECTED1','Con seleccionado:');
define('INFO_TEXT_CLEAR_MARK','Marca clara');
define('INFO_TEXT_DELETE','Borrar');
define('INFO_TEXT_RESTORE','Restaurar');
define('INFO_TEXT_HAS_NOT_FOUND','no has encontrado ningún correo.');
define('INFO_TEXT_PLEASE_CHECK_ONE','Marca al menos una casilla de verificación.');

?>