<?
define('HEADING_TITLE','Detalles de la empresa');
define('ERROR_COMPANY_DETAILS_NOT_EXIST','¡Oops! Los detalles de la empresa no existen. El Equipo WaoJobs está para ayudarte, escríbenos AQUÍ.');
define('IMAGE_BACK','Atrás');
define('INFO_TEXT_LATEST_POSITIONS','Oportunidades laborales más recientes');
define('INFO_TEXT_JOBS','Lista de oportunidades laborales');
//*********************************************************************//
define('INFO_TEXT_CURRENT_RATING','Valoración actual : ');
define('INFO_TEXT_CURRENT_RATE_IT','Puntúalo');
define('INFO_TEXT_CURRENT_RATE_STRING','');
define('SECTION_RATE_COMPANY','Tasa de empresa');
define('INFO_TEXT_NOT_RATED','No clasificado');
define('MESSAGE_SUCCESS_RATED','Reclutador calificado con éxito.');
?>