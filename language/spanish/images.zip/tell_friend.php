<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Dile a tu amigo');
define('SUCCESS_EMAIL_SENT','Tu mensaje enviado con éxito a tu amigo.');
define('INFO_TEXT_FROM_NAME','Tu nombre completo: ');
define('INFO_TEXT_FROM_EMAIL_ADDRESS','Tu dirección de correo electrónico: ');
define('INFO_TEXT_TO_NAME','Nombre completo de tu amigo: ');
define('INFO_TEXT_TO_EMAIL_ADDRESS','La dirección de correo electrónico de tu amigo:');
define('INFO_TEXT_SUBJECT','Sujeto: ');
define('INFO_TEXT_MESSAGE','Mensaje: ');
define('INFO_TEXT_SECURITY_CODE','Código de seguridad:');
define('INFO_TEXT_TYPE_CODE','Escribe el código mostrado');
define('ERROR_SECURITY_CODE','¡Oops! Código de seguridad no válido.');
define('IMAGE_SEND','Enviar');
define('INFO_TEXT_HI','¡Hola!');
define('INFO_TEXT_YOUR_FRIEND','Tu amigo');
define('INFO_TEXT_HAS_SENT','te ha enviado un mensaje.');
define('INFO_TEXT_EMAIL_ADDRESS','La dirección de correo electrónico es:');
define('INFO_TEXT_MESSAGE','El mensaje es el siguiente ...');
define('INFO_TEXT_TYPE_CODE','Escribe el código mostrado');

?>