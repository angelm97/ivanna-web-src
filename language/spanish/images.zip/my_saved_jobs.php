<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', 'Lista de oportunidades laborales guardadas');
//////////////////////////
define('TABLE_HEADING_JOB_TITLE', 'Título profesional');
define('TABLE_HEADING_COMPANY_NAME', 'Nombre de empresa');
define('TABLE_HEADING_ADVERTISED', 'Anunciado en');
define('TABLE_HEADING_EXPIRED', 'Expirado el');
define('TABLE_HEADING_DELETE', 'Borrar');
define('TABLE_HEADING_APPLY', 'Solicitar');

define('MESSAGE_SUCCESS_DELETED','¡Listo! Trabajo eliminado correctamente.');

define('MESSAGE_JOB_ERROR','¡Oops! Este oportunidad laboral ya no se encuentra. Si el problema persiste, comunícate con el Equipo WaoJobs AQUÍ.');
define('INFO_TEXT_APPLY_NOW','¡Aplica ya!');
?>