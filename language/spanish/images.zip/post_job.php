<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/

define('HEADING_TITLE','Anunciar un trabajo');
define('REQUIRED_INFO','* Información requerida');
define('INFO_TEXT_JOB_TITLE','Título profesional:');
define('INFO_TEXT_HOSPITAL_NAME','Nombre de empresa:');
define('INFO_TEXT_JOB_REF','Referencia laboral:');
define('ENTRY_JOB_REFERENCE_ERROR', '¡Oops! Esta referencia de trabajo ya existe.');
define('ENTRY_JOB_TITLE_ERROR', '¡Oops! Este puesto de trabajo ya existe.');

define('INFO_TEXT_COUNTRY','País:');
define('ENTRY_COUNTRY_ERROR', 'Seleccionar un país.');
define('PLEASE_SELECT','Por favor selecciona');

define('INFO_TEXT_STATE','Expresar:');
define('ENTRY_STATE_ERROR_SELECT', 'Seleccione una provincia.');
define('ENTRY_STATE_ERROR', 'Se requiere tu estado.');
define('INFO_TEXT_PERMISSION_ERROR','¡Oops! No tienes permiso.');

define('ENTRY_VACANCY_SUMMARY_ERROR', 'Ingresa el resumen de vacantes. ');
define('ENTRY_DESCRIPTION_ERROR', ' Ingresa la descripción de la oportunidad laboral. ');
define('ENTRY_JOB_CATEGORY_ERROR', ' Selecciona al menos la categoría laboral. ');

define('INFO_TEXT_LOCATION','Ubicación:');

define('INFO_TEXT_SALARY','Salario:');
define('INFO_TEXT_SKILLS','Habilidades de trabajo:');
define('INFO_TEXT_SEPARATED',"separado por comas");


define('INFO_TEXT_INDUSTRY_SECTOR','Descripción del trabajo:');
define('INFO_TEXT_VACANCY_SUMMARY','Resumen de trabajo:');
define('INFO_TEXT_DESCRIPTION','Descripción del trabajo:');
define('INFO_TEXT_APPLICATION_GOTO','Las hojas de vida de los candidatos irán a:');
define('INFO_TEXT_APPLICATION_GOTO2','Para agregar una dirección de correo electrónico, vaya a administrar usuarios en el panel de control');
define('INFO_TEXT_JOB_TYPE','Tipo de empleo:');
define('INFO_TEXT_RELOCATE','Mostrar a los candidatos <br>¿Dispuesto a reubicarse?:');
define('INFO_TEXT_EXPERIENCE','Experiencia requerida:');
define('INFO_TEXT_ADVERTISE_WEEKS','Fecha de cierre de contabilización:');
define('INFO_TEXT_ADVERTISE_DATE','La vacante se agregará el:');
define('ENTRY_READVERTISE_ERROR','Ingresaste incorrectamente "Fecha de cierre" o "Fecha de publicación" o ambas.');
define('ENTRY_CLOSING_DATE_ERROR','Diferencia entre la fecha de adición de vacante y la fecha de cierre de publicación máxima '.INFO_TEXT_MAX_JOB_DURATION.' Reduce la fecha de cierre posterior');
define('INFO_TEXT_JOB_AUTO_RENEW','Renovación automática de trabajos :');

define('JOB_POST_INVOICE_SUBJECT','Factura de puesto de trabajo');

define('MESSAGE_SUCCESS_UPDATED','¡Listo! Vacante actualizada');
define('MESSAGE_SUCCESS_INSERTED','¡Listo! Vacante ingresada');
define('MESSAGE_ERROR_JOB','¡Oops! Esta oportunidad laboral no existe.');

define('IMAGE_PREVIEW','Vista previa de la oportunidad laboral');
define('IMAGE_NEW','Agregar oportunidad laboral');
define('IMAGE_UPDATE','Actualizar oportunidad laboral');
define('IMAGE_CANCEL','Cancelar');
define('IMAGE_CONFIRM','Confirmar');
define('IMAGE_BACK','atrás');
define('INFO_TEXT_ALL_JOB_TYPE','Todos los tipos de oportunidades laborales');
define('INFO_TEXT_YES','Si');
define('INFO_TEXT_NO','No');
define('INFO_TEXT_PLEASE_SELECT','Selecciona un país...');
define('INFO_TEXT_ANY_EXPERIENCE','Cualquier experiencia');
define('INFO_TEXT_STATE','Expresar');
define('INFO_TEXT_NOT_MENTIONED','No mencionado');
define('INFO_TEXT_POST_URL','Aplica online:');
define('ENTRY_ENTER_URL_ERROR','Ingresa una URL');
define('INFO_TEXT_APPLICATION_GOTO_URL','El candidato será redirigido a:');
define('ENTRY_SALARY_ERROR','Ingresa el salario solo en dígitos');
define('INFO_TEXT_JOBFAIR','Feria de trabajo :');
?>