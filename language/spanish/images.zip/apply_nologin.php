<?
define('HEADING_TITLE','Aplicar sin iniciar sesión');
define('INFO_TEXT_NAME','Nombre : ');
define('INFO_TEXT_EMAIL','Correo electrónico : ');
define('INFO_TEXT_SUBJECT','Sujeto : ');
define('INFO_TEXT_UPLOAD_RESUME','Subir hoja de vida : ');

define('ERROR_RESUME_NOT_EXIST','¡Oops! Primero debes agregar tu hoja de vida.');
define('ERROR_JOB_NOT_EXIST','¡Oops! Esta oportunidad laboral ya no se encuentra.');
define('INFO_TEXT_CV','Adjunta tu hoja de vida : ');
define('ERROR_RESUME_SEND','¡Oops! Selecciona reanudar para cargar.');
define('ENTER_NAME_ERROR','¡Oops! Ingresa el nombre');
define('ENTER_EMAIL_ERROR','¡Oops! Ingresa la dirección de correo electrónico');
define('MESSAGE_SUCCESS_APPLED','¡Cada vez más ceerca al trabajo de tus sueños! Aquí hay algunos otras oportunidades laborales cerca que pueden interesarte.');
define('SUCCESS_RESUME_SEND','Reanudar el envío con éxito.');
////
define('IMAGE_CONFIRM','¡Quiero aplicar!');
define('INFO_TEXT_MESSAGE','Mensaje');
define('INFO_TEXT_UPLOAD_RESUME_HELP','Subir formato txt / doc / docx / pdf');
define('CAPTCHA_ERROR_1','Selecciona el archivo para cargar');
define('INFO_TEXT_SECURITY_CODE','Código de seguridad:');
define('INFO_TEXT_TYPE_CODE','Escribe el código mostrado');
define('ERROR_SECURITY_CODE','¡Oops! Código de seguridad no válido.');
?>