<?
define('HEADING_TITLE','Descripción de la empresa');
define('MESSAGE_SUCCESS_INSERTED','¡Listo! Descripción de empresa insertada.');
define('MESSAGE_SUCCESS_UPDATED','¡Listo! Descripción de la empresa actualizada.');
define('IMAGE_INSERT','Insertar');
define('IMAGE_UPDATE','Actualizar');
define('IMAGE_PREVIEW','Avance');
define('IMAGE_BACK','Atrás');
?>